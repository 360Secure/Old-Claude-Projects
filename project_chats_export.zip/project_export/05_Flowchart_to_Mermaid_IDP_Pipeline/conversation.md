# Flowchart to Mermaid Code Conversion
**Date:** 2026-03-17  
**URL:** https://claude.ai/chat/6e708fed-ae2d-4ced-bd85-47092e48bebc

## Summary
Converted an IDP Pipeline flowchart from a Word document image into Mermaid diagram code.

## Key Topics
- PDF/Word image extraction
- IDP Pipeline architecture
- Mermaid diagram syntax

## Pipeline Flow
PDF Input → PDF to Image → Image Enhancement → Rotation/Skew Correction → OCR → Quality Classifier → Page/Block Splitter → Router/VLM Selector → [Gemini | Claude | GPT-4V | OWEN | Table-VLM] → VLM Extraction → Post Processing → Math Validation → Final Structured JSON → Human Review → Approved Invoice Record

## Conversation

**User:** For flowchart in attached doc, generate mermaid code.

**Claude:** Extracted flowchart image from the .docx file and generated Mermaid code — see artifact.
