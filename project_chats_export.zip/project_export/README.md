# Project Chat Export
**Exported:** 2026-04-28  
**Total Chats:** 6

## Chat Index

| Folder | Title | Date |
|--------|-------|------|
| 01_Git_collaboration_setup | Git Collaboration Setup for Assignment Submission | 2026-04-27 |
| 02_Liquid_Model_Invoice_Extraction_and_KCET_Math | Liquid Model for Invoice Extraction + KCET Math Prep | 2026-04-23 |
| 03_Vision_Transformer_KNO_Store | Vision Transformer & KNO Store | 2026-04-03 |
| 04_IDP_Project_Folder_Structure | IDP Project Folder Structure | 2026-03-19 |
| 05_Flowchart_to_Mermaid_IDP_Pipeline | Flowchart to Mermaid Conversion | 2026-03-17 |
| 06_Invoice_Parser_Code_Review | Invoice Parser Code Review (Qwen3-VL) | 2026-02-27 |

## Artifacts Included

| Chat | Artifact | Type |
|------|----------|------|
| 02 | KCET_Maths_Complete_Prep.html | Interactive HTML study guide |
| 04 | setup_idp_poc.sh | Bash project setup script |
| 05 | idp_pipeline.mermaid | Mermaid diagram code |

## How to Use
- Open `conversation.md` in any chat folder to read the full conversation
- Open `.html` artifacts in a browser
- Run `.sh` scripts with `bash artifact_setup_idp_poc.sh`
- Render `.mermaid` files at https://mermaid.live
