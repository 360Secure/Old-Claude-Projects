# Invoice Parser Code Review (Qwen3-VL)
**Date:** 2026-02-27  
**URL:** https://claude.ai/chat/e0ad7a19-cb05-41ef-9e80-6a64f2fa5eed

## Summary
Code review of invoice_parser_v1.py — a Colab-based PDF invoice extractor using Qwen3-VL vision model.

## Key Topics
- Qwen3-VL model setup on Google Colab
- PDF to image conversion
- JSON structured output extraction
- Model loading class name fix

## Bugs Found

### 1. Duplicate poppler-utils install
Installed in both Cell 2 (`!apt-get`) and Cell 4 (`subprocess.run`). Remove one.

### 2. Broken print statement
```python
# WRONG
print(f"VRAM: ..." if condition else print("N/A"))

# CORRECT
vram = f"..." if condition else "N/A"
print(f"VRAM: {vram}")
```

### 3. Wrong model class name
```python
# WRONG
from transformers import Qwen2VLForConditionalGeneration

# CORRECT
from transformers import AutoModelForImageTextToText
model = AutoModelForImageTextToText.from_pretrained(
    model_id, torch_dtype=torch.float16, device_map="auto"
)
```

### 4. Missing repetition penalty
```python
output_ids = model.generate(
    **inputs,
    max_new_tokens=2048,
    do_sample=False,
    repetition_penalty=1.1,  # ADD THIS — prevents "RRRR" output
)
```

## Improvements Suggested
- Add retry on JSON parse failure (use `json-repair` library)
- Add `torch.cuda.empty_cache()` after each page inference
- Consider file picker widget for PDF upload
- Bump `max_new_tokens` to 4096 for complex invoices
- Add page-level error logging

## Mac-specific Notes
- Use `brew install poppler` instead of `apt-get install poppler-utils`
- Or skip poppler: `pip install PyMuPDF` (pure Python, no system deps)
- For Apple Silicon GPU: set `device = "mps"` instead of `"cuda"`
- Donut-base model (~200M params, ~800MB) runs fine on 16GB MacBook Pro
