# IDP Project Folder Structure Organization
**Date:** 2026-03-19  
**URL:** https://claude.ai/chat/a39f6cc7-f0cc-4ec1-adea-653151ad4e6e

## Summary
Designing a clean, professional folder structure for an Invoice Document Processing (IDP) pipeline project.

## Key Topics
- IDP POC project layout
- Input/output/intermediate file organization
- Notebook organization (local vs Colab)
- Setup script generation

## Recommended Project Structure

```
idp-invoice/
├── data/
│   └── raw/                    # Original invoice PDFs only
├── input/
│   └── invoice/
│       ├── sample_invoice.pdf
│       └── sample_invoice_ground_truth.json
├── output/
│   ├── images/                 # inputfilename_dpivalue_page1.png
│   ├── ocr/                    # inputfilename_ocr.json
│   ├── vlm/                    # inputfilename_vlm.json
│   └── final/                  # inputfilename_final.json
├── src/
│   ├── preprocessing.py
│   ├── ocr_engine.py
│   ├── vlm_extractor.py
│   ├── postprocessing.py
│   └── utils.py
├── notebooks/
│   ├── local/
│   │   ├── 01_preprocessing.ipynb
│   │   └── 02_ocr_benchmark.ipynb
│   └── colab/
│       └── 03_vlm_benchmark.ipynb
├── models/
│   └── model_registry.yaml
├── .env
├── requirements.txt
└── README.md
```

## Key Design Decisions
- **data/raw/** — original PDFs only, never modified
- **output/** — all intermediate outputs with descriptive naming convention
- **input/** — ground truth JSONs alongside source PDFs
- **notebooks/** split by local vs Colab execution environment
- **utils.py** lives in src/ alongside other modules
