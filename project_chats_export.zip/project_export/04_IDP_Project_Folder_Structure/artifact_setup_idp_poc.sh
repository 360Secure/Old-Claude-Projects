#!/usr/bin/env bash
# ============================================================
# IDP POC — Invoice Processing Project Setup Script
# Usage: bash setup_idp_poc.sh [target_directory]
# ============================================================

BASE_DIR="${1:-idp-invoice}"

echo "Creating IDP POC structure at: $BASE_DIR"

# Core directories
mkdir -p "$BASE_DIR"/{data/raw,data/samples}
mkdir -p "$BASE_DIR"/input/invoice
mkdir -p "$BASE_DIR"/output/{images,ocr,vlm,final}
mkdir -p "$BASE_DIR"/src
mkdir -p "$BASE_DIR"/notebooks/{local,colab}
mkdir -p "$BASE_DIR"/models
mkdir -p "$BASE_DIR"/reports

# requirements.txt
cat > "$BASE_DIR/requirements.txt" << 'REQ'
# Core
python-dotenv==1.0.0
pillow==10.2.0
numpy==1.26.4
pandas==2.2.1

# PDF processing
pdf2image==1.17.0
PyMuPDF==1.23.26

# OCR
pytesseract==0.3.10
paddleocr==2.7.3

# VLM / LLM clients
openai==1.12.0
anthropic==0.21.3
google-generativeai==0.4.1
transformers==4.39.3
torch==2.2.1

# Utilities
tqdm==4.66.2
jsonschema==4.21.1
json-repair==0.6.0
REQ

# .env template
cat > "$BASE_DIR/.env" << 'ENV'
OPENAI_API_KEY=your_key_here
ANTHROPIC_API_KEY=your_key_here
GOOGLE_API_KEY=your_key_here
AZURE_OCR_KEY=your_key_here
AZURE_OCR_ENDPOINT=your_endpoint_here
ENV

# Model registry
cat > "$BASE_DIR/models/model_registry.yaml" << 'YAML'
models:
  - name: donut-base-finetuned-docvqa
    provider: huggingface
    size_gb: 0.8
    task: document_vqa
    status: downloaded

  - name: naver-clova-ix/donut-base-finetuned-cord-v2
    provider: huggingface
    size_gb: 0.8
    task: receipt_parsing
    status: not_downloaded
YAML

# src/ stubs
for module in preprocessing ocr_engine vlm_extractor postprocessing utils; do
cat > "$BASE_DIR/src/${module}.py" << PY
"""
${module}.py — IDP POC
TODO: implement
"""
PY
done

# Notebook stubs
for nb in "local/01_preprocessing" "local/02_ocr_benchmark" "colab/03_vlm_benchmark"; do
cat > "$BASE_DIR/notebooks/${nb}.ipynb" << 'NB'
{
 "cells": [
  {"cell_type": "markdown", "metadata": {}, "source": ["# TODO: implement"]}
 ],
 "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}, "language_info": {"name": "python", "version": "3.10.0"}},
 "nbformat": 4,
 "nbformat_minor": 5
}
NB
done

# README
cat > "$BASE_DIR/README.md" << 'README'
# IDP POC — Invoice Processing Pipeline

## Overview
Extracts structured JSON from invoice PDFs using OCR + VLM pipeline.

## Structure
- `data/raw/` — original PDFs (never modified)
- `input/invoice/` — test PDFs + ground truth JSONs  
- `output/` — intermediate outputs (images, OCR, VLM, final JSON)
- `src/` — pipeline modules
- `notebooks/local/` — run on MacBook
- `notebooks/colab/` — run on Google Colab (GPU)
- `models/` — model registry

## Output Naming Convention
- Images: `{filename}_dpi300_page1.png`
- OCR: `{filename}_ocr.json`
- VLM: `{filename}_vlm.json`
- Final: `{filename}_final.json`

## Setup
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env .env.local  # fill in your API keys
```
README

echo ""
echo "✅ IDP POC structure created at: $BASE_DIR"
echo "   Folders: $(find "$BASE_DIR" -type d | wc -l | tr -d ' ')"
echo "   Files:   $(find "$BASE_DIR" -type f | wc -l | tr -d ' ')"
