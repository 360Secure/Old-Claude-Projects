# Chat: Document page scanner with question and image detection
**Date:** 2026-04-16
**URL:** https://claude.ai/chat/79ca6901-920f-4293-9483-968a89585d37

---

## Artifacts created
| File | Description |
|------|-------------|
| `artifacts/AI_Scanner_Questions.ipynb` | Initial HuggingFace vision notebook |
| `artifacts/AI_Scanner_Anthropic.ipynb` | Revised notebook using Anthropic Claude API |
| `artifacts/AI_Scanner_MultiProvider.ipynb` | Final notebook — Gemini + Groq + OpenRouter with auto-fallback |

---

## User
I have a notebook in colab. I just want to run a model to see from my drive from AI_Scanner Folder /Page1.png and make it so that it can identify questions in the page, which page it is, like even though it says page 130 in bottom, it's page 1. Make it use AI from HuggingFace to separate questions with options, and identify if some questions or some answers have Images. For example:
- Q1 - What is 8^4, explain in graph
- Op1 - (Is Image Completely)
- Op2 - It Is like this (Has A Image And text)
- Op3 - (Is Image Completely)
- Op4 - None Of the above

Make it save in .csv file

## Assistant
Created `AI_Scanner_Questions.ipynb` — a Google Colab notebook that:
- Mounts Google Drive and loads images from `AI_Scanner/` folder
- Calls HuggingFace Inference API (`meta-llama/Llama-3.2-11B-Vision-Instruct`)
- Extracts questions, options, and image-presence flags as structured JSON
- Saves results to CSV (appending if file already exists)

**Output CSV columns:** `logical_page`, `q_number`, `question_text`, `question_has_image`, `option_a_text`, `option_a_has_image`, `option_b_text`, `option_b_has_image`, `option_c_text`, `option_c_has_image`, `option_d_text`, `option_d_has_image`, `correct_answer`

---

## User
_(HuggingFace API was unreliable for vision — switched to Anthropic)_

## Assistant
Switched to `AI_Scanner_Anthropic.ipynb` using the Anthropic Claude API (`claude-sonnet-4-5`). More reliable for vision tasks on exam pages.

**Setup:** Add `ANTHROPIC_API_KEY` to Colab Secrets (🔑 sidebar) and enable "Notebook access".

---

## User
_(Rate limit errors with Gemini 2.0 Flash)_

```
Page 1/3 (PDF #1) [gemini]
WARNING:tornado.access:429 POST /v1beta/models/gemini-2.0-flash:generateContent...
  GEMINI rate-limited
  >> All providers exhausted. Waiting 60s then resetting...
```

## Assistant
Created the main `AI_Scanner_MultiProvider.ipynb` with:
- **Gemini** (primary) → **Groq** → **OpenRouter** fallback chain
- Auto-detects best available model for each provider
- Handles rate limits by switching providers automatically
- Waits 60s and resets if all providers exhausted

**Fix for Gemini:** Model preference order now puts `gemini-1.5-flash-latest` first (confirmed working), with `gemini-2.0-flash` last since it has 0 quota in some regions.

---

## User
which model you use

## Assistant
Primary model used: **`gemini-1.5-flash-latest`**

The auto-picker in Cell 3 tries this order:
1. `gemini-1.5-flash-latest` ← selected
2. `gemini-1.5-flash-001`
3. `gemini-1.5-flash-002`
4. `gemini-1.5-pro-latest`
5. `gemini-2.0-flash` (last — 0 quota in your region)

Free quota: 15 req/min, 1500 req/day.

---

## User
with groq

## Assistant
For Groq the model used is **`meta-llama/llama-4-scout-17b-16e-instruct`** — newest vision-capable model on Groq's free tier as of April 2026.

Free limits:
- 30 requests/minute
- 500,000 tokens/day
- Resets at midnight UTC

To list available models on your account:
```python
from groq import Groq
client = Groq(api_key=GROQ_KEY)
for m in client.models.list().data:
    print(m.id)
```
