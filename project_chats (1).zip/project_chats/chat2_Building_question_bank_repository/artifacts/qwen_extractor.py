"""
Qwen2.5-VL Local GPU Question Extractor
========================================
Artifact from: Building a question bank repository from scanned documents
Chat: https://claude.ai/chat/ef73a2fe-54e6-4939-9910-0484d5f0b3be

Requirements:
    pip install transformers accelerate qwen-vl-utils pillow pdf2image psycopg2-binary boto3

Usage:
    python qwen_extractor.py --pdf Scan.pdf --output questions.csv
"""

import argparse, json, os, re, time
from pathlib import Path

# ── Install check ──────────────────────────────────────────────────────────────
try:
    from transformers import Qwen2VLForConditionalGeneration, AutoProcessor
    from qwen_vl_utils import process_vision_info
    from pdf2image import convert_from_path
    from PIL import Image
    import torch
except ImportError as e:
    print(f"Missing dependency: {e}")
    print("Run: pip install transformers accelerate qwen-vl-utils pillow pdf2image")
    raise


# ── Model loader ───────────────────────────────────────────────────────────────
def load_model(model_id: str = "Qwen/Qwen2.5-VL-7B-Instruct"):
    """Load Qwen2.5-VL model. Use 7B on single GPU, 32B/72B on multi-GPU."""
    print(f"Loading model: {model_id}")
    model = Qwen2VLForConditionalGeneration.from_pretrained(
        model_id,
        torch_dtype=torch.bfloat16,
        device_map="auto",
    )
    processor = AutoProcessor.from_pretrained(
        model_id,
        min_pixels=256 * 28 * 28,
        max_pixels=1280 * 28 * 28,  # controls resolution vs speed tradeoff
    )
    print(f"Model loaded on: {next(model.parameters()).device}")
    return model, processor


# ── Extraction prompt ──────────────────────────────────────────────────────────
PROMPT = """You are an expert at reading scanned Indian exam question papers (MCQ format).
Extract ALL multiple choice questions visible on this page.

For each question return a JSON object with:
{
  "q_number": <int>,
  "question_text": "<text, empty string if purely a diagram/figure>",
  "question_has_image": <bool>,
  "option_a_text": "<text>",
  "option_a_has_image": <bool>,
  "option_b_text": "<text>",
  "option_b_has_image": <bool>,
  "option_c_text": "<text>",
  "option_c_has_image": <bool>,
  "option_d_text": "<text>",
  "option_d_has_image": <bool>,
  "correct_answer": "A"|"B"|"C"|"D"|null,
  "section": "<section heading if visible, else empty string>",
  "status": "complete"|"partial"|"continuation"
}

Rules:
- set *_has_image=true if that field contains or IS a diagram/figure
- set status="partial" if question starts but options spill to next page
- set status="continuation" if this page continues options from previous page
- Return ONLY a valid JSON array. No markdown. No explanation."""


# ── Single-page extraction ─────────────────────────────────────────────────────
def extract_questions_from_page(
    pil_image: Image.Image,
    model,
    processor,
    sequential_page: int,
) -> list[dict]:
    """Run Qwen2.5-VL on one page image and return list of question dicts."""
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": pil_image},
                {
                    "type": "text",
                    "text": f"Sequential page {sequential_page}.\n{PROMPT}",
                },
            ],
        }
    ]

    text_input = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    image_inputs, _ = process_vision_info(messages)
    inputs = processor(
        text=[text_input],
        images=image_inputs,
        padding=True,
        return_tensors="pt",
    ).to(model.device)

    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=2048,
            temperature=0.1,
            do_sample=False,
        )

    # Decode only the new tokens
    generated = output_ids[:, inputs["input_ids"].shape[1]:]
    response = processor.batch_decode(generated, skip_special_tokens=True)[0]

    return _parse_json(response)


def _parse_json(text: str) -> list[dict]:
    """Robustly extract JSON array from model output."""
    text = text.strip()
    text = re.sub(r"^```[\w]*\n?", "", text)
    text = re.sub(r"\n?```$", "", text).strip()
    try:
        result = json.loads(text)
        return result if isinstance(result, list) else [result]
    except Exception:
        m = re.search(r"(\[.*\])", text, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(1))
            except Exception:
                pass
    print(f"  Warning: Could not parse JSON from response: {text[:200]}")
    return []


# ── PDF processing pipeline ────────────────────────────────────────────────────
def process_pdf(
    pdf_path: str,
    output_csv: str,
    model_id: str = "Qwen/Qwen2.5-VL-7B-Instruct",
    dpi: int = 200,
    page_range: tuple | None = None,
) -> None:
    import pandas as pd

    model, processor = load_model(model_id)

    # Render pages
    print(f"\nRendering PDF: {pdf_path}")
    pages = convert_from_path(pdf_path, dpi=dpi)
    if page_range:
        pages = pages[page_range[0] - 1 : page_range[1]]
    print(f"Pages to process: {len(pages)}")

    all_rows = []
    for seq_idx, pil_img in enumerate(pages, start=1):
        print(f"\nPage {seq_idx}/{len(pages)} ...", end=" ", flush=True)
        t0 = time.time()
        questions = extract_questions_from_page(pil_img, model, processor, seq_idx)
        elapsed = time.time() - t0
        print(f"{len(questions)} questions ({elapsed:.1f}s)")

        for q in questions:
            all_rows.append(
                {
                    "pdf_page": seq_idx,
                    "q_number": q.get("q_number"),
                    "status": q.get("status", "complete"),
                    "section": q.get("section", ""),
                    "question_text": q.get("question_text", ""),
                    "question_has_image": q.get("question_has_image", False),
                    "option_a_text": q.get("option_a_text", ""),
                    "option_a_has_image": q.get("option_a_has_image", False),
                    "option_b_text": q.get("option_b_text", ""),
                    "option_b_has_image": q.get("option_b_has_image", False),
                    "option_c_text": q.get("option_c_text", ""),
                    "option_c_has_image": q.get("option_c_has_image", False),
                    "option_d_text": q.get("option_d_text", ""),
                    "option_d_has_image": q.get("option_d_has_image", False),
                    "correct_answer": q.get("correct_answer"),
                }
            )

        # Save incrementally every 5 pages
        if seq_idx % 5 == 0:
            _save_csv(all_rows, output_csv)
            print(f"  (auto-saved {len(all_rows)} rows)")

    _save_csv(all_rows, output_csv)
    print(f"\n✅ Done. {len(all_rows)} total questions → {output_csv}")


def _save_csv(rows: list[dict], path: str) -> None:
    import pandas as pd

    df = pd.DataFrame(rows)
    if os.path.exists(path):
        df_existing = pd.read_csv(path)
        df = pd.concat([df_existing, df], ignore_index=True).drop_duplicates(
            subset=["pdf_page", "q_number"]
        )
    df.to_csv(path, index=False)


# ── CLI ────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Extract MCQ questions from scanned PDFs")
    parser.add_argument("--pdf", required=True, help="Path to scanned PDF")
    parser.add_argument("--output", default="questions.csv", help="Output CSV path")
    parser.add_argument(
        "--model",
        default="Qwen/Qwen2.5-VL-7B-Instruct",
        help="HuggingFace model ID (7B, 32B, or 72B)",
    )
    parser.add_argument("--dpi", type=int, default=200, help="Render DPI (200 recommended)")
    parser.add_argument(
        "--pages",
        nargs=2,
        type=int,
        metavar=("START", "END"),
        help="Page range to process (1-indexed)",
    )
    args = parser.parse_args()

    page_range = tuple(args.pages) if args.pages else None
    process_pdf(args.pdf, args.output, args.model, args.dpi, page_range)
