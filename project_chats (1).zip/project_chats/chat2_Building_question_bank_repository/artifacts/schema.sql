-- ============================================================
-- Question Bank Database Schema
-- ============================================================
-- Artifact from: Building a question bank repository from scanned documents
-- Chat: https://claude.ai/chat/ef73a2fe-54e6-4939-9910-0484d5f0b3be
--
-- Run with: psql -U your_user -d your_db -f schema.sql
-- ============================================================

-- Source documents tracking
CREATE TABLE IF NOT EXISTS source_documents (
    id              SERIAL PRIMARY KEY,
    filename        TEXT NOT NULL,
    book_title      TEXT,
    subject         TEXT,
    grade_level     TEXT,
    total_pages     INT,
    processed_pages INT DEFAULT 0,
    status          TEXT DEFAULT 'pending',  -- pending | processing | complete | error
    uploaded_at     TIMESTAMP DEFAULT NOW(),
    completed_at    TIMESTAMP
);

-- Main questions table
CREATE TABLE IF NOT EXISTS questions (
    id                    SERIAL PRIMARY KEY,
    source_doc_id         INT REFERENCES source_documents(id),
    pdf_page              INT NOT NULL,
    question_number       INT,
    sequential_q_number   INT,  -- auto-assigned global question number
    status                TEXT DEFAULT 'complete',  -- complete | partial | continuation
    section               TEXT,
    question_text         TEXT,
    question_has_image    BOOLEAN DEFAULT FALSE,
    question_image_url    TEXT,   -- S3/GCS URL if diagram was cropped & uploaded
    option_a_text         TEXT,
    option_a_has_image    BOOLEAN DEFAULT FALSE,
    option_a_image_url    TEXT,
    option_b_text         TEXT,
    option_b_has_image    BOOLEAN DEFAULT FALSE,
    option_b_image_url    TEXT,
    option_c_text         TEXT,
    option_c_has_image    BOOLEAN DEFAULT FALSE,
    option_c_image_url    TEXT,
    option_d_text         TEXT,
    option_d_has_image    BOOLEAN DEFAULT FALSE,
    option_d_image_url    TEXT,
    correct_answer        CHAR(1),   -- A, B, C, or D
    ai_confidence         FLOAT,     -- optional: model confidence score
    human_verified        BOOLEAN DEFAULT FALSE,
    human_corrected       BOOLEAN DEFAULT FALSE,
    extracted_at          TIMESTAMP DEFAULT NOW(),
    verified_at           TIMESTAMP
);

-- Indices for common query patterns
CREATE INDEX IF NOT EXISTS idx_questions_source    ON questions(source_doc_id);
CREATE INDEX IF NOT EXISTS idx_questions_section   ON questions(section);
CREATE INDEX IF NOT EXISTS idx_questions_answer    ON questions(correct_answer);
CREATE INDEX IF NOT EXISTS idx_questions_verified  ON questions(human_verified);
CREATE INDEX IF NOT EXISTS idx_questions_has_img   ON questions(question_has_image);

-- Full-text search index on question text
CREATE INDEX IF NOT EXISTS idx_questions_fts
    ON questions USING GIN(to_tsvector('english', COALESCE(question_text, '')));

-- Optional: tags for categorization
CREATE TABLE IF NOT EXISTS question_tags (
    question_id  INT REFERENCES questions(id) ON DELETE CASCADE,
    tag          TEXT NOT NULL,
    PRIMARY KEY (question_id, tag)
);

-- Human review queue
CREATE TABLE IF NOT EXISTS review_queue (
    id            SERIAL PRIMARY KEY,
    question_id   INT REFERENCES questions(id) ON DELETE CASCADE,
    reason        TEXT,   -- 'low_confidence' | 'has_image' | 'random_sample'
    assigned_to   TEXT,
    status        TEXT DEFAULT 'pending',  -- pending | in_review | done
    created_at    TIMESTAMP DEFAULT NOW()
);

-- ── Useful views ──────────────────────────────────────────────────────────────

-- Questions needing review (has image but not verified)
CREATE OR REPLACE VIEW unverified_image_questions AS
SELECT q.id, q.source_doc_id, q.pdf_page, q.question_number,
       q.question_text, q.question_has_image,
       q.option_a_has_image, q.option_b_has_image,
       q.option_c_has_image, q.option_d_has_image
FROM questions q
WHERE (q.question_has_image
    OR q.option_a_has_image OR q.option_b_has_image
    OR q.option_c_has_image OR q.option_d_has_image)
  AND q.human_verified = FALSE;

-- Source document progress summary
CREATE OR REPLACE VIEW processing_summary AS
SELECT
    sd.id, sd.filename, sd.status,
    sd.total_pages,
    COUNT(q.id) AS questions_extracted,
    SUM(CASE WHEN q.human_verified THEN 1 ELSE 0 END) AS questions_verified,
    SUM(CASE WHEN q.question_has_image OR q.option_a_has_image OR q.option_b_has_image
             OR q.option_c_has_image OR q.option_d_has_image THEN 1 ELSE 0 END) AS questions_with_images
FROM source_documents sd
LEFT JOIN questions q ON q.source_doc_id = sd.id
GROUP BY sd.id, sd.filename, sd.status, sd.total_pages;
