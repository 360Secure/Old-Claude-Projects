# Chat: Building a question bank repository from scanned documents
**Date:** 2026-04-04
**URL:** https://claude.ai/chat/ef73a2fe-54e6-4939-9910-0484d5f0b3be

---

## Artifacts created
| File | Description |
|------|-------------|
| `artifacts/schema.sql` | PostgreSQL database schema for the question bank |
| `artifacts/qwen_extractor.py` | Local GPU extraction script using Qwen2.5-VL |

---

## User
I want to make a testing platform for students. I have scanned multiple Book/Question papers containing multiple choice questions. These questions and answers may or may not contain diagrams.

I want to push all these questions into a database from scanned copies of books or question papers. This is a very important step for making a repository of questions. My plan is to use a few thousand scanned book/question papers. So to prepare such a question bank repository — how to store it and how to handle diagrams in questions and answers?

## Assistant
Analyzed the uploaded `Scan.pdf` — identified as IMO-style MCQ papers with mixed text and diagram-heavy questions (dice, mirror images, pattern series).

### Complete Architecture Blueprint

**Pipeline stages:**
1. **Ingest** — PDF/image upload, render to per-page images at 200–300 DPI
2. **Vision AI extraction** — send page image to model, receive structured JSON
3. **Storage** — PostgreSQL for structured data, S3/GCS for diagram image crops
4. **Human review** — verify AI output, especially for image-heavy questions

**Database schema (see `schema.sql`):**
- `source_documents` — tracks each PDF, processing status, page count
- `questions` — stores extracted text, image flags, S3 URLs for diagram crops
- `review_queue` — human verification workflow
- Views for unverified image questions and processing progress

**Diagram handling strategy:**
- Detect via `*_has_image` boolean flags from Vision AI
- Crop bounding box regions from page image
- Upload crops to S3/GCS
- Store URL in corresponding `*_image_url` column

**Recommended Stack:**
- Vision AI: Claude 3.5 Sonnet or GPT-4o (API) — or Qwen2.5-VL locally
- Storage: PostgreSQL + AWS S3 or Google Cloud Storage
- Processing: Python pipeline with multiprocessing / job queue (Celery + Redis)
- Review UI: Label Studio or custom Next.js app

### Scale estimate (1,000s of books)
At ~200 pages/book × 3,000 books = 600K pages.
- API approach: ~$400–$2,500 total cost
- Local Qwen2.5-VL: near-zero cost (electricity only), 2–5 pages/min on T4

---

## User
I have a GPU machine and want to use Qwen or similar open-source VLM model for this task. Does it make sense?

## Assistant
Yes — strongly recommended for this use case. The economics are decisive.

**Accuracy (OmniDocBench benchmark):**
- Qwen2.5-VL-72B: 87.02
- GPT-4o: 75.02
- Qwen2.5-VL-7B: competitive with GPT-4o on structured document extraction

**Model size recommendations by GPU:**
| GPU | Model | Speed |
|-----|-------|-------|
| RTX 3090/4090 (24GB) | Qwen2.5-VL-7B-Instruct | ~3-5 pages/min |
| A100 40GB | Qwen2.5-VL-7B or 32B (4-bit) | ~5-8 pages/min |
| 2× A100 80GB | Qwen2.5-VL-32B or 72B (4-bit) | ~3-4 pages/min |

**Fine-tuning roadmap (see `qwen_extractor.py` for extraction pipeline):**

**Phase 1 — Bootstrap:** Use Claude/GPT-4o API as teacher model for first 100 books. Manually verify ~500 extractions → gold dataset.

**Phase 2 — Fine-tune Qwen2.5-VL-7B with LoRA:**
```python
# Training data format (LLaMA-Factory or Axolotl)
{
  "messages": [
    {"role": "user", "content": [
      {"type": "image", "image": "page_001.jpg"},
      {"type": "text", "text": "Extract all MCQ questions as JSON..."}
    ]},
    {"role": "assistant", "content": "[{...verified JSON...}]"}
  ]
}
```
On A100 40GB with LoRA: ~1–2 hours for 500 examples.

**Phase 3 — Fine-tuned model processes everything at near-zero cost.**
Accuracy jumps from ~75% baseline to 90–95% on in-domain Indian exam papers.

### Economics

| Approach | Cost for 500K pages | Accuracy | Speed |
|---|---|---|---|
| Claude/GPT-4o API | ~$2,500–$5,000 | ~85% | Rate limited |
| Qwen7B baseline local | ~$0 | ~75% | 2–5 pages/min |
| **Fine-tuned Qwen7B** | **~$100 one-time** | **~90–95%** | **2–5 pages/min** |

### Key consideration for diagram-as-option questions
For questions where all four options ARE diagrams (no text), the prompt must explicitly request diagram descriptions and bounding boxes:
```python
# In your prompt:
"If an option has NO text and is purely a visual figure, set type='diagram'
and write a brief description of what the diagram shows."
```

**Note:** Anthropic permits using Claude outputs to train other models as long as you're not training a model to impersonate Claude.
