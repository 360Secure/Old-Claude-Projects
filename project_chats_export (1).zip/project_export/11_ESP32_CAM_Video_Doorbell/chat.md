# ESP-32 CAM Two-Way Communication — AI Video Doorbell

**Date:** 2026-03-21  
**URL:** https://claude.ai/chat/e53b90ee-bd1e-4157-981f-08209ea27460

## Project Goal
AI Video Door Bell: visitor at door can talk to homeowner over mobile app; homeowner opens door remotely via GPIO/relay.

## Requirements
- **Platform:** Both Android & iOS + Web browser (mobile-friendly)
- **Backend:** Cloud-based (AWS/Firebase)
- **Experience level:** Intermediate

## ESP32-CAM Limitations
- Limited RAM (~520KB) — hard to run full WebRTC stack
- No hardware H.264 encoder
- No built-in audio codec
→ **Recommended alternative: ESP32-S3** (better CPU, more RAM)

## Architecture Chosen
**Outdoor:** ESP32-S3 or Pi-based camera → RTSP → EC2 → WebRTC to mobile
**Door control:** GPIO → relay → electric strike

## Product Strategy (Two Tiers)
| Tier | Hardware | BOM (volume) | Features |
|------|----------|--------------|---------|
| Standard | ESP32-S3 + Android app | ~$60–80 | Cloud face recog, WebRTC audio/video |
| Premium | Pi 4 + dedicated indoor panel | ~$150–180 | Local face recog, 1080p H.264 |

## Pinhole Camera Design (Pi 4 Inside Door)
Pi 4 hidden inside the door, powering:
- Outside: pinhole camera + bell button + LED ring
- Inside: flush-mounted touchscreen panel

### Questions Raised
- **Door type:** Wooden hollow/solid, Metal, Glass/composite
- **Door thickness:** Standard 35–45mm vs Thick/security 60–80mm
- **Visible outside:** Only pinhole lens + optional LED ring
- **Visible inside:** Flush-mounted screen on door interior face

## Premium BOM Breakdown
| Component | Part | Cost |
|-----------|------|------|
| Main MCU | Raspberry Pi 4 (4GB) | $45 |
| Camera | Wide-angle CSI pinhole | $15 |
| Audio | I2S mic + 3W speaker | $8 |
| Fingerprint | R503 capacitive (or R502-F IP65) | $12 |
| Door lock | 12V fail-secure electric strike | $20 |
| Relay | 5V relay module | $3 |
| Power outdoor | 12V 2A PSU + 5V buck converter | $7 |
| Enclosure | IP65 weatherproof box | $10 |
| Indoor MCU | Pi Zero 2W | $15 |
| Indoor display | Waveshare 4.3" DSI touchscreen | $32 |
| Indoor audio | USB mini audio dongle + speaker | $8 |
| **Total** | | **~$195** |

Volume (100+ units): Pi 4 drops to ~$35, Pi Zero to ~$12 → total BOM ~$150–180.
