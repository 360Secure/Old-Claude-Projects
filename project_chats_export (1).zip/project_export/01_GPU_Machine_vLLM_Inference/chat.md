# GPU machine selection for vLLM inference deployment

**Date:** 2026-04-24  
**URL:** https://claude.ai/chat/d886295c-4f91-4549-907e-fd0a3d314a4c

## Summary
Discussion about buying a GPU machine for the AI Gate Keeper project to reduce AWS and LLM API costs by deploying vLLM locally for inference.

## Context
- Project: AI Gate Keeper
- Current stack: Pi Zero 2W + ESP32-S3, AWS Rekognition for face recognition, LiveKit WebRTC
- Goal: Cut AWS + LLM API costs by running inference locally

## GPU Comparison (Interactive widget was shown in chat)
Compared GPU options for running vLLM inference locally vs cloud costs.

---

## Claude Design Feature (also covered)
- Available at: claude.ai/design
- Has its **own separate weekly usage limit** (shown alongside "All models" limit in Settings)
- Chat interface on left, canvas on right

### How to use
- Start with: text prompt, uploaded images/docs (DOCX, PPTX, XLSX), or codebase link
- Web capture tool grabs elements from your actual website for realistic prototypes

### Example prompts
- "Design a mobile app onboarding flow with 4 screens"
- "Build a landing page for our new API product with a hero section and pricing"
- "Create a pitch deck for our AI Gate Keeper product — 10 slides"

### Refining designs
- Conversational chat: broad changes ("make the color scheme darker")
- Inline comments: click on specific element for targeted tweak
- Custom sliders created by Claude

### Brand / Design System
- Built during onboarding by reading your codebase and design files
- Subsequent projects auto-use your colors, typography, components

### Exporting
- Share as internal URL
- Save as folder
- Export to: Canva, PDF, PPTX, standalone HTML
- Handoff bundle for Claude Code

### Best for
- Founders building pitch decks without a designer
- PMs creating wireframes/feature flow mockups
- Marketers making landing pages/one-pagers
- Designers rapidly exploring multiple directions

### Known limitations (research preview)
- Inline comments may disappear → paste into chat as workaround
- Compact layout mode can trigger save errors → use full view
- Linking large repos may lag → link specific subdirectories
