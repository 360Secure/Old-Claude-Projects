# Website image upload to Raspberry Pi

**Date:** 2026-04-09  
**URL:** https://claude.ai/chat/f88892de-0663-4ccc-a0e0-a09c11fba39b

## Summary
Built a system where a website lets users take up to 10 photos and upload them to a folder on Raspberry Pi 5. Uses the existing EC2 WebSocket control channel (same as pi_control.py).

## Architecture
```
Browser (camera UI)
      ↓ POST /upload (multipart)
EC2 FastAPI
      ↓ WebSocket (base64 photo messages)
pi_control.py on Pi
      ↓ saves files
~/received_photos/ folder
```

## Files Built

### 1. Upload Webpage
- Camera viewfinder using getUserMedia
- "Take Photo" button (up to 10 photos)
- Thumbnail grid preview
- "Upload All" button → POST to EC2
- Progress indicator

### 2. EC2 FastAPI — /upload endpoint
```python
@app.post("/upload")
async def upload_photos(files: List[UploadFile]):
    for f in files:
        data = await f.read()
        b64 = base64.b64encode(data).decode()
        await pi_ws.send(json.dumps({
            "type": "photo",
            "filename": f.filename,
            "data": b64
        }))
    return {"uploaded": len(files)}
```

### 3. pi_control.py — Photo handler addition
```python
elif msg["type"] == "photo":
    folder = Path.home() / "received_photos"
    folder.mkdir(exist_ok=True)
    img_bytes = base64.b64decode(msg["data"])
    out_path = folder / msg["filename"]
    out_path.write_bytes(img_bytes)
    print(f"📸 Saved: {out_path}")
```

## GStreamer Pipeline Fix (same chat)
Fixed `Internal data stream error` in pi_publisher.py by explicitly forcing NV12 format:

```python
PUBLISH_PIPELINE = f"""
 libcamerasrc ! video/x-raw,width=1280,height=720,framerate=30/1,format=NV12 ! videoconvert !
 vp8enc deadline=1 target-bitrate=800000 ! rtpvp8pay pt=96 !
 webrtcbin name=pub bundle-policy=max-bundle stun-server=stun://stun.l.google.com:19302

 pulsesrc ! audio/x-raw,rate=48000,channels=1,format=S16LE !
 audioconvert ! audioresample ! opusenc bitrate=64000 ! rtpopuspay pt=111 !
 pub.
"""
```

Cause: pipeline was trying 1920x1080 RAW which webrtcbin couldn't handle.

## SCRIPTS.md Final State
| Script | Location | Status |
|--------|----------|--------|
| pi_publisher.py | /home/naman/ | Active |
| pi_control.py | /home/naman/ | Active (systemd) |
| main.py | /home/ubuntu/app/ | Active (FastAPI) |
| pi1.html | /var/www/pi/ | **Active production interface** |
| dashboard.html | /var/www/pi/ | Obsolete/suspended |
