# Raspberry Pi 5 — Face Recognition Solenoid Unlock

**Date:** 2026-04-07  
**URL:** https://claude.ai/chat/63566b25-f472-4851-8d37-b13d14219105

## Summary
Extended GPIO solenoid control to add face recognition. Known faces in folder structure; face recognized consistently for 2+ seconds triggers "Welcome" + 5-second unlock.

## Original GPIO Code (Starting Point)
```python
import RPi.GPIO as GPIO
import time

RELAY = 18
TOUCH = 23

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(RELAY, GPIO.OUT)
GPIO.setup(TOUCH, GPIO.IN)
GPIO.output(RELAY, 1)  # relay OFF initially

while True:
    if GPIO.input(TOUCH) == 1:   # touched
        print("Touched! Unlocking...")
        GPIO.output(RELAY, 0)    # relay ON (active LOW)
        time.sleep(3)
        GPIO.output(RELAY, 1)    # relay OFF
        time.sleep(1)
    time.sleep(0.1)
```

## Enhanced System Architecture

### Known Faces Folder Structure
```
known_faces/
├── tia/
│   ├── tia1.jpg
│   └── tia2.jpg
└── naman/
    ├── naman1.jpg
    └── naman2.jpg
```

### Recognition Logic
1. Mobile browser runs **face-api.js** (FaceNet-style recognition)
2. Builds descriptor database from `known_faces/` on startup
3. Detects face → tracks consistency
4. Same name held for **2+ continuous seconds** → sends unlock command to Pi
5. Pi Flask server receives command → opens solenoid for **5 seconds**
6. Prints: `"Welcome, [name]!"`

### System Components
| Component | Role |
|-----------|------|
| face_unlock.py | Pi Flask server + ArcFace recognition engine |
| Browser HTML | Runs face-api.js, sends commands to Pi |
| known_faces/ | Folder-based face database |

### face_unlock.py Expected Output
```
[INFO] ArcFace ready.
[INFO] Building face database...
  ✓ tia <- tia1.jpg
[INFO] Running — press Ctrl+C or q to quit.

[FACE] Detected: tia  dist=0.312
*** Welcome, tia! Opening for 5s ***
*** Door locked ***
```

## Important Note
The Picamera2 web preview server (port 8000) is completely separate from face_unlock.py. Browser errors like `/control/status failed` from that interface can be ignored — face_unlock.py runs headlessly in terminal.
