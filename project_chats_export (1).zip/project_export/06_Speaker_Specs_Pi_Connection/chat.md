# Speaker Specs and Raspberry Pi Connection

**Date:** 2026-04-13  
**URL:** https://claude.ai/chat/96d6fafa-c8cf-4138-996b-3ef9fb923c53

## Speaker Specifications (28mm Mylar Transducer)
- **Size:** 28mm diameter (Φ28mm)
- **Type:** Mylar speaker/transducer — NOT a buzzer
  - Multi-functional: receiver + speaker modes
  - Wide frequency range (Fo ~10KHz) — unlike buzzers (single fixed freq)
  - THD < 5% at 1KHz
  - Rated for: DVD players, telephones, alarm systems
- **SPL:** 93 ± 3 dB (at 0.1W, 0.1 meter on-axis)
- **Rated power:** 0.25W continuous, 0.5W max
- **Frequency range:** 680Hz ~ 10KHz
- **Impedance:** 8Ω

## Music Playback
Yes — works like a phone/intercom speaker. Limitations:
- Weak bass below 680Hz
- Only 28mm, so modest volume
- Similar to a mobile phone speaker

## Connecting to Raspberry Pi 5
| Method | Notes |
|--------|-------|
| Direct 3.5mm jack | Not recommended — 8Ω too low impedance |
| **USB Audio Adapter + PAM8403 amp** | Recommended, ~$2, simple |
| I2S DAC HAT (PCM5102A / MAX98357A) | Best quality, direct GPIO |

## Resistor Fix (ESP32 GPIO → Relay)
- 220Ω failed — too low for reliable relay drive
- **Need:** 10kΩ (Brown-Black-Orange-Gold) or 1kΩ (Brown-Black-Red-Gold)
- Buy at SP Road, Bengaluru: VB Enterprises, Chips & Components, Vishal Electronics
- ₹5 for 10 pieces; resistor kit (600 pcs) ~₹80
- **Tip:** Get a breadboard (~₹80) — prevents breaking resistors
