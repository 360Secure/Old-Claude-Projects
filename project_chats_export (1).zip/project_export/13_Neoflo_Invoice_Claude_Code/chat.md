# Removing Attached Folder from Claude Code — Neoflo Invoice Parsing

**Date:** 2026-03-09  
**URL:** https://claude.ai/chat/56121b36-4587-491a-ba17-81017eb4a270

## Summary
How to detach `~/script/Neoflo_InvoiceParsing` from a Claude Code session.

## Options

### Option 1: Bottom bar
Click on `~/script/Neoflo_InvoiceParsing` shown at the bottom of the Claude Code window → option to detach/remove folder appears.

### Option 2: "+" menu
Click the **+** icon (bottom left, next to "Ask permissions") → look for "Remove folder" or "Change working directory".

### Option 3: New session
Start a **New session** — new session won't have the folder attached unless you re-add it.

## Note
The folder shown at the bottom is Claude Code's working directory. Removing it means Claude Code loses direct access to those files for that session only — files on disk are not affected.
