# Uvicorn Restart — Quick Reference

**Date:** 2026-04-07  
**URL:** https://claude.ai/chat/a3faf4f5-b608-4327-84d2-d394fa7c68df

## Summary
Terminal output shared showing successful uvicorn restart and status check.

## Commands Used
```bash
pkill -f "uvicorn main:app"
sleep 1
cd /home/ubuntu/app
nohup uvicorn main:app --host 0.0.0.0 --port 8000 &
sleep 2
curl http://localhost:8000/control/status
```

## Expected Output
```json
{"pi_connected":false,"streaming":false}
```

Server was confirmed running. `pi_connected: false` is normal when Pi control agent isn't connected yet.
