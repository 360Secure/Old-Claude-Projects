#!/usr/bin/env python3
"""
360Secure — Pi Control Agent
Maintains a persistent WebSocket to EC2 control server.
Starts/stops pi_publisher.py on command.

Install on Pi:  /home/naman/pi_control.py
Run:            python3 ~/pi_control.py
Auto-start:     Add to systemd (see bottom of file)
"""

import asyncio
import json
import subprocess
import signal
import sys
import os

import websockets

# ── Config ────────────────────────────────────────────────────────────────────
CONTROL_WS_URL = "wss://api.360secure.in/ws/pi-control"
PUBLISHER_CMD  = [sys.executable, os.path.expanduser("~/pi_publisher.py")]
RECONNECT_SEC  = 5
# ──────────────────────────────────────────────────────────────────────────────

publisher_proc = None


def is_running():
    return publisher_proc is not None and publisher_proc.poll() is None


async def handle(ws):
    global publisher_proc
    print("✅ Connected to EC2 control channel")
    await ws.send(json.dumps({"type": "hello", "device": "pi1"}))

    async for raw in ws:
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            continue

        cmd = msg.get("command")
        print(f"📩 Received: {cmd}")

        if cmd == "start":
            if is_running():
                await ws.send(json.dumps({"type": "status", "value": "already_running"}))
            else:
                publisher_proc = subprocess.Popen(PUBLISHER_CMD)
                print(f"▶️  Publisher started (pid {publisher_proc.pid})")
                await ws.send(json.dumps({"type": "status", "value": "started"}))

        elif cmd == "stop":
            if is_running():
                publisher_proc.send_signal(signal.SIGINT)
                publisher_proc.wait()
                print("⏹  Publisher stopped")
                await ws.send(json.dumps({"type": "status", "value": "stopped"}))
            else:
                await ws.send(json.dumps({"type": "status", "value": "not_running"}))

        elif cmd == "status":
            await ws.send(json.dumps({
                "type": "status",
                "value": "running" if is_running() else "stopped"
            }))


async def main():
    while True:
        try:
            async with websockets.connect(CONTROL_WS_URL) as ws:
                await handle(ws)
        except Exception as e:
            print(f"⚠️  Connection lost: {e}. Reconnecting in {RECONNECT_SEC}s…")
            await asyncio.sleep(RECONNECT_SEC)


if __name__ == "__main__":
    asyncio.run(main())


# ── Systemd service (save as /etc/systemd/system/pi-control.service) ──────────
# [Unit]
# Description=360Secure Pi Control Agent
# After=network-online.target
# Wants=network-online.target
#
# [Service]
# ExecStart=/usr/bin/python3 /home/naman/pi_control.py
# Restart=always
# User=naman
#
# [Install]
# WantedBy=multi-user.target
#
# Enable: sudo systemctl enable --now pi-control
