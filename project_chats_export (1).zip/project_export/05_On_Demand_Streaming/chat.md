# Building an on-demand streaming service

**Date:** 2026-04-16  
**URL:** https://claude.ai/chat/5d1fd64c-eb4b-4016-91f3-0f72c103ddbb

## Summary
Built a start/stop streaming control system: clicking a button on the webpage starts pi_publisher.py on the Pi, and clicking stop kills it. Uses a persistent WebSocket from Pi to EC2.

## Architecture
```
Browser → clicks Start/Stop button on webpage
        → calls https://api.360secure.in/control/start (or /stop)
             ↓
        EC2 FastAPI sends command over persistent WebSocket
             ↓
        pi_control.py (Pi) receives → starts/stops pi_publisher.py subprocess
```

## Files Created

### 1. pi_control.py (Pi)
**Location:** `/home/naman/pi_control.py`

Key config:
```python
CONTROL_WS_URL = "wss://api.360secure.in/ws/pi-control"
PUBLISHER_CMD  = [sys.executable, os.path.expanduser("~/pi_publisher.py")]
RECONNECT_SEC  = 5
```

Features:
- Persistent WebSocket to EC2 control server
- Starts/stops pi_publisher.py subprocess on command
- Auto-reconnects on disconnect
- Sends status updates back to EC2

### 2. FastAPI EC2 Endpoints
| Endpoint | Method | Action |
|----------|--------|--------|
| /ws/pi-control | WS | Pi connects here |
| /control/start | POST | Sends "start" to Pi |
| /control/stop | POST | Sends "stop" to Pi |
| /control/status | GET | Returns pi_connected + streaming status |

### 3. Updated HTML (pi1.html)
Start/Stop button added to webpage. Calls `/control/start` and `/control/stop`. Shows live status.

---

## Mobile Fix Applied
**Problem:** CSS rotation (`transform: rotate(90deg)`) was breaking mobile browser intercom.

**Fix:** Remove the `@media screen and (max-width:900px) and (orientation:portrait)` CSS block from provision.py.

**Steps:**
```bash
nano /home/ubuntu/360secure/provision.py
# Delete the CSS rotation media query line
cp /home/ubuntu/360secure/provision.py /home/ubuntu/app/main.py
pkill -f "uvicorn main:app"
cd /home/ubuntu/app
nohup uvicorn main:app --host 0.0.0.0 --port 8000 >> uvicorn.log 2>&1 &
curl -X POST 'https://api.360secure.in/provision/new?name=Test6'
```

Open new viewer_url on phone in **landscape mode manually** — intercom now works.
