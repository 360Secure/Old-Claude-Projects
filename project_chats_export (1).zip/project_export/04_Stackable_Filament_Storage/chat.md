# Stackable filament storage for Anycubic i3 Mini / Bambu A1 Mini

**Date:** 2026-04-18  
**URL:** https://claude.ai/chat/54e0de9b-e717-4c22-a9e6-32c064bcd242

## Summary
Designed a parametric OpenSCAD model for a lightweight, stackable, drawer-style filament storage compartment. Designed for the A1 Mini with target weight under 40g.

## Design Specs
- **Estimated weight:** ~31g (at 15% infill, 2 walls, PLA)
- **Under 40g target:** ✅ Met
- **Stackable:** Male pegs on top lock into female slots on unit below — press down to click, no hardware
- **Drawer style:** Slides open by pulling forward
- **Ventilation:** Honeycomb pattern on side walls

## Dimensions (defaults)
| Dimension | Value |
|-----------|-------|
| Width | 120mm |
| Depth | 150mm |
| Height | 55mm |

## Key OpenSCAD Parameters
| Parameter | Default | Purpose |
|-----------|---------|---------|
| drawer_height | 55mm | Increase for bulkier items |
| hex_cell_r | 5mm | Bigger = fewer holes, lighter |
| add_divider | true | Set false for single open bay |
| peg_count | 3 | More = stronger stack lock |
| slot_clearance | 0.25mm | Increase to 0.3mm if pegs too tight |

## Print Settings
- **Orientation:** Flat on bed (bottom face down)
- **Supports:** None required
- **Walls:** 2 perimeter walls
- **Infill:** 15% gyroid
- **Layer height:** 0.2mm
- **Brim:** Not needed (large flat footprint)

## Workflow
1. Download [OpenSCAD](https://openscad.org) (free)
2. Open the `.scad` file → press **F6** to render (~10–30 sec for honeycomb)
3. Set `show_stack_demo = false` before exporting
4. **File → Export → Export as STL**
5. Slice in Bambu Studio with settings above

## Artifact Generated
**File:** `a1mini_filament_drawer.scad` — Full parametric OpenSCAD source code

## Stacking Mechanism
Each unit has:
- **Bottom:** Female slots (receive pegs from unit below)
- **Top:** Male pegs (insert into unit above)

Press down to click — units lock together without screws or glue.
The ghost `%` stacked unit in the preview is automatically excluded from STL export.
