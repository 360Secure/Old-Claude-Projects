// ============================================================
//  A1 Mini / Anycubic i3 — Stackable Filament Storage Drawer
//  Parametric OpenSCAD Model
//  Target: < 40g printed in PLA at 15% gyroid, 2 walls
// ============================================================

// ── User Parameters ──────────────────────────────────────────
drawer_width   = 120;    // mm — outer width
drawer_depth   = 150;    // mm — outer depth (front to back)
drawer_height  =  55;    // mm — outer height
wall_t         =   1.6;  // mm — wall thickness (matches 2-wall 0.4mm nozzle)

// Honeycomb ventilation
hex_cell_r     =   5;    // mm — hex cell radius (flat-to-flat/2)
hex_wall       =   1.0;  // mm — hex wall thickness
vent_margin    =  10;    // mm — solid border around vent area

// Stacking pegs & slots
peg_h          =   4;    // mm — peg height above top rim
peg_r          =   3;    // mm — peg outer radius
peg_count      =   3;    // per rail side
slot_clearance =   0.25; // mm — increase to 0.3 if printer runs tight

// Rail (guides drawer into unit below)
rail_w         =   6;    // mm — rail width
rail_h         =   3;    // mm — rail depth below bottom

// Divider
add_divider    = true;
divider_t      =   1.2;  // mm

// Handle
handle_w       =  40;    // mm
handle_h       =  12;    // mm
handle_d       =   8;    // mm

// Preview only — disable before exporting STL
show_drawer    = true;
show_stack_demo= true;   // shows a ghost unit stacked on top

// ── Derived ──────────────────────────────────────────────────
inner_w = drawer_width  - 2*wall_t;
inner_d = drawer_depth  - 2*wall_t;
inner_h = drawer_height -   wall_t;   // open top

// ============================================================
//  MODULES
// ============================================================

module hex_grid(width, depth, cell_r, wall_th) {
    // Honeycomb pattern using difference of rectangles minus hexagons
    hex_w = cell_r * 2;
    hex_h = cell_r * sqrt(3);
    cols  = floor(width  / (hex_w + wall_th)) + 2;
    rows  = floor(depth  / (hex_h + wall_th)) + 2;
    offset_x = -hex_w;
    offset_y = -hex_h;
    for (r = [0:rows-1]) {
        for (c = [0:cols-1]) {
            x = offset_x + c * (hex_w + wall_th) + (r % 2) * (hex_w + wall_th) / 2;
            y = offset_y + r * (hex_h * 0.75 + wall_th);
            translate([x, y, 0])
                cylinder(r=cell_r, h=100, $fn=6, center=false);
        }
    }
}

module vent_side(width, height) {
    // Side wall with honeycomb cutouts
    difference() {
        cube([width, wall_t, height]);
        translate([vent_margin, -0.1, vent_margin])
            intersection() {
                cube([width - 2*vent_margin, wall_t + 0.2, height - 2*vent_margin]);
                rotate([90, 0, 0])
                    hex_grid(width - 2*vent_margin, height - 2*vent_margin, hex_cell_r, hex_wall);
            }
    }
}

module snap_peg() {
    cylinder(r=peg_r, h=peg_h, $fn=32);
    // chamfer top
    translate([0, 0, peg_h - 1])
        cylinder(r1=peg_r, r2=peg_r*0.6, h=1, $fn=32);
}

module snap_slot() {
    cylinder(r=peg_r + slot_clearance, h=peg_h + 0.5, $fn=32);
}

module rail_side(side) {
    // Sliding rail — guides drawer into stack unit
    mirror_v = (side == "left") ? [0, 0, 0] : [1, 0, 0];
    translate(mirror_v)
    mirror(mirror_v)
    translate([0, 0, -rail_h])
        cube([rail_w, drawer_depth, rail_h]);
}

module handle() {
    translate([drawer_width/2 - handle_w/2, -handle_d, drawer_height/2 - handle_h/2])
        difference() {
            cube([handle_w, handle_d, handle_h]);
            translate([4, -0.1, 4])
                cube([handle_w - 8, handle_d + 0.2, handle_h - 8]);
        }
}

module divider() {
    translate([drawer_width/2 - divider_t/2, wall_t, wall_t])
        cube([divider_t, inner_d, inner_h]);
}

module full_drawer() {
    difference() {
        union() {
            // Floor
            cube([drawer_width, drawer_depth, wall_t]);

            // Back wall (solid)
            translate([0, drawer_depth - wall_t, 0])
                cube([drawer_width, wall_t, drawer_height]);

            // Left wall (vented)
            vent_side(drawer_depth, drawer_height);

            // Right wall (vented)
            translate([drawer_width - wall_t, 0, 0])
                vent_side(drawer_depth, drawer_height);

            // Rails
            rail_side("left");
            rail_side("right");

            // Stacking pegs (top of each rail)
            for (s = [-1, +1]) {
                x_pos = (s < 0) ? rail_w/2 : drawer_width - rail_w/2;
                peg_spacing = (drawer_depth - 2*vent_margin) / (peg_count - 1);
                for (i = [0 : peg_count-1]) {
                    py = vent_margin + i * peg_spacing;
                    translate([x_pos, py, drawer_height])
                        snap_peg();
                }
            }

            // Handle
            handle();

            // Divider
            if (add_divider) divider();
        }

        // Female slots in floor (receive pegs from unit below)
        for (s = [-1, +1]) {
            x_pos = (s < 0) ? rail_w/2 : drawer_width - rail_w/2;
            peg_spacing = (drawer_depth - 2*vent_margin) / (peg_count - 1);
            for (i = [0 : peg_count-1]) {
                py = vent_margin + i * peg_spacing;
                translate([x_pos, py, -rail_h - 0.01])
                    snap_slot();
            }
        }
    }
}

// ============================================================
//  RENDER
// ============================================================

if (show_drawer) {
    full_drawer();
}

// Ghost stacked unit above (for assembly preview — disable before export)
if (show_stack_demo) {
    %translate([0, 0, drawer_height + rail_h*2 + peg_h])
        full_drawer();
}

// ============================================================
//  PRINT NOTES
//  Orient: flat on bed (bottom face down), no supports required.
//  The front opening faces +Y. Slice with:
//    - 2 perimeter walls
//    - 15% gyroid infill
//    - 0.2 mm layer height
//    - No brim needed (large flat footprint)
//  Set show_stack_demo = false before exporting STL.
// ============================================================
