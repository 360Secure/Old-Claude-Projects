# AI-powered smart gate keeper with ESP32 S3

**Date:** 2026-04-21  
**URL:** https://claude.ai/chat/2f766aa2-25ca-4c77-a539-2408723fe251

## System Flow
```
Visitor presses button
        ↓
Device starts video + audio stream (WebRTC / RTSP)
        ↓
User gets notification (mobile app)
        ↓
User sees + talks (real-time)
        ↓
Parallel:
  Image → AWS → Face Recognition
        ↓
Decision:
  Auto unlock OR user taps unlock
        ↓
Relay triggers door
```

## Requirements
- **Deployment:** Single home/apartment
- **Users:** Under 10 (family)
- **Must-haves:**
  - Two-way audio/video call
  - Cloud face recognition
  - Fingerprint unlock (optical touch-based)
  - Multi-user mobile app
  - RFID/PIN backup
- **Connectivity:** Wi-Fi always available
- **Power:** Mains power (wall panel)

## Hardware Stack
- **Outdoor MCU:** ESP32-S3
- **Indoor:** Pi Zero 2W
- **Camera:** OV2640 or CSI module
- **Fingerprint:** R503 capacitive (or R502-F IP65)
- **Face Recognition:** AWS Rekognition (cloud)
- **Communication:** WebRTC via LiveKit
- **Door lock:** 12V fail-secure electric strike + 5V relay module
- **Backup access:** RFID + PIN keypad

---

## JEE Physics 2025 — Complete Revision Sheet
*(This was the other major topic in this chat)*

### High-Frequency Question Patterns (2023–2025)
| Topic | Exam occurrences |
|-------|-----------------|
| Magnetic dipole τ = MBsinθ | 2023 Q1, 2024 Q6 |
| Curie-Weiss χ₁/χ₂ at different temperatures | 2023 Q6, 2024 Q22 |
| LCR Q factor from graph OR voltage across L or C | 2023 Q15, 2025 Q40 |
| Photoelectric threshold wavelength or stopping potential | 2023 Q24, 2024 Q39 |
| Bohr model ratio of radii, areas or energy | 2024 Q41 |
| Young's double slit intensity at x = β/n | 2023 Q22 |
| Malus's law through 2 or 3 polaroids | 2023 Q21, 2024 Q36 |
| Radioactive decay time for activity to reach 1/x | 2023 Q30 |
| Self inductance find L from ε and dI/dt | 2023 Q8 |
| Circular motion in B ratio of radii | 2023 Q3 |
| p-n junction conceptual | 2023 Q31, 2024 Q45 |

### Quick Revision Formulas

**MAGNETISM**
- τ = MBsinθ → zero at θ=0°, max at θ=90°
- r = mv/qB → r ∝ m/q (same v)
- T = 2πm/qB → independent of v
- χ = C/(T−Tc)
- L = ε·Δt/ΔI
- S = IgG/(I−Ig)

**ELECTROSTATICS**
- Φ = Q/ε₀ → inside conductor Φ=0
- Dipole in closed surface → Φ=0
- W = q(VA−VB)

**CURRENT ELECTRICITY**
- vd ↑ when I ↑ at constant T
- μ = constant at constant T
- BB ROY GB VGW → 0 to 9
- Gold band = ±5%

**LCR & AC**
- Z = √(R²+(XL−XC)²)
- Resonance: Z=R, φ=0, pf=1
- Q = ω₀/(ω₂−ω₁)
- Vrms = V₀/√2, f = ω/2π

**OPTICS**
- 1/f = 1/v − 1/u
- β = λD/d
- At x=β/3 → I = I₀ (equal slits)
- I = I₀cos²θ (Malus)
- Unpolarised → I₀/2 after first polaroid
- sinC = 1/μ → max C for Red

**MODERN PHYSICS**
- E(eV) = 1240/λ(nm)
- KE = hf − φ = eV₀
- rₙ = n²r₁, Eₙ = −13.6/n² eV
- t = T½ × log₂(N₀/N)
- KE_α = Q×(A−4)/A

**MECHANICS**
- μ = cotθ (hanging block equilibrium)
- I_disc = MR²/2, I_ring = MR²
- g_h = g(R/(R+h))² → at h=R/2: g_h = 4g/9

**SEMICONDUCTORS**
- n-type: donor level just below conduction band
- Depletion: no free carriers at all
- Forward bias external wire: electrons only

### Common Traps
| Wrong | Correct |
|-------|---------|
| τ = 0 at θ=90° | τ = 0 at θ = **0°** |
| Ideal transformer changes power | P_in = P_out **always** |
| Full wave rectifier: each diode 100× at 50Hz | Each diode **50 times** |
| μ increases when I increases | μ = **constant** at constant T |
| W ≠ 0 on equipotential | W = **0** |
| Same λ → same energy | Same λ → same **p only** |
| n-type donor above valence band | Just **below** conduction band |
| Critical angle max for violet | Max for **Red** |
