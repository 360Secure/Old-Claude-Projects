# Project Export — Claude Chat History
**Exported:** 2026-04-28

This archive contains all conversations from this Claude project, organized into folders by chat.
Each folder contains a `chat.md` with the full summary, key decisions, code snippets, and notes.
Code artifacts and files generated during chats are included alongside the chat summaries.

---

## Chat Index

| Folder | Topic | Date |
|--------|-------|------|
| 01_GPU_Machine_vLLM_Inference | GPU selection for vLLM inference + Claude Design feature | 2026-04-24 |
| 02_AI_Device_Redesign_Integrated_Components | Physical device redesign, manual lock, Pi S2R power management | 2026-04-22 |
| 03_AI_Smart_Gate_Keeper_ESP32_S3 | Full system plan: ESP32-S3, WebRTC, AWS Rekognition, fingerprint + JEE physics | 2026-04-21 |
| 04_Stackable_Filament_Storage | Parametric OpenSCAD stackable drawer for A1 Mini (<40g) | 2026-04-18 |
| 05_On_Demand_Streaming | Start/stop streaming via webpage button; mobile CSS fix | 2026-04-16 |
| 06_Speaker_Specs_Pi_Connection | 28mm speaker specs, Pi 5 audio connection, resistor fix | 2026-04-13 |
| 07_Website_Image_Upload_Pi | Browser → EC2 → Pi photo upload system; GStreamer NV12 fix | 2026-04-09 |
| 08_Face_Recognition_Solenoid_Unlock | FaceNet/ArcFace recognition → GPIO solenoid unlock | 2026-04-07 |
| 09_Pi_WebSocket_Control | Persistent WebSocket control channel; SCRIPTS.md | 2026-04-06 |
| 10_Uvicorn_Restart_Reference | Uvicorn restart commands and status check | 2026-04-07 |
| 11_ESP32_CAM_Video_Doorbell | ESP32-CAM options, two-tier product strategy, pinhole design, BOM | 2026-03-21 |
| 12_Janus_WebRTC_Audio | Full-duplex audio via Janus VideoRoom + Bluetooth speaker | 2026-03-04 |
| 13_Neoflo_Invoice_Claude_Code | Detaching folder from Claude Code session | 2026-03-09 |

---

## Project: AI Gate Keeper — 360Secure

### Core System
- **Outdoor:** ESP32-S3 camera + bell + fingerprint sensor
- **Indoor:** Pi Zero 2W (wall panel) with screen + speaker + mic
- **Backend:** EC2 FastAPI + Janus WebRTC
- **Domain:** api.360secure.in / live.360secure.in
- **Cloud:** AWS Rekognition for face recognition
- **Mobile:** WebRTC viewer via LiveKit or Janus

### Key Files on Pi
| File | Path | Purpose |
|------|------|---------|
| pi_publisher.py | ~/pi_publisher.py | GStreamer WebRTC camera stream |
| pi_control.py | ~/pi_control.py | Persistent WS control agent |
| face_unlock.py | ~/face_unlock.py | ArcFace recognition + GPIO unlock |

### Key Files on EC2
| File | Path | Purpose |
|------|------|---------|
| main.py | /home/ubuntu/app/ | FastAPI server |
| pi1.html | /var/www/pi/ | Active production viewer |

### Useful Commands
```bash
# EC2 — restart server
pkill -f "uvicorn main:app"
cd /home/ubuntu/app && nohup uvicorn main:app --host 0.0.0.0 --port 8000 >> uvicorn.log 2>&1 &

# EC2 — check status
curl http://localhost:8000/control/status

# Pi — start control agent
python3 ~/pi_control.py

# Pi — manual stream start
python3 ~/pi_publisher.py
```
