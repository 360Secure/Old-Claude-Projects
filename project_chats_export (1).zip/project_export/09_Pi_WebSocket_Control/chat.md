# Pi WebSocket Control — Turning Something On/Off

**Date:** 2026-04-06  
**URL:** https://claude.ai/chat/90a04826-2bc2-4bbd-9184-4b49f12d48c7

## Summary
Built the persistent WebSocket control infrastructure from scratch. Pi connects to EC2 and waits for start/stop commands. Also created SCRIPTS.md to document all project scripts.

## Architecture
```
Browser → pi1.html
        → POST https://api.360secure.in/control/start (or /stop)
             ↓
        EC2 FastAPI relays command over persistent WebSocket
             ↓
        pi_control.py (Pi) → starts/stops pi_publisher.py
```

## pi_control.py (Pi Side — Initial Version)
```python
EC2_CONTROL_WS = "wss://live.360secure.in/pi-control-ws"
PUBLISHER_CMD  = ["python3", "/home/naman/pi_publisher.py"]
```

Commands handled:
- `start` → launch pi_publisher.py subprocess
- `stop` → SIGINT to publisher, wait for exit
- `status` → return running/stopped

## FastAPI EC2 (main.py additions)
```python
@app.websocket("/pi-control-ws")
async def pi_control_ws(websocket: WebSocket):
    # Pi connects here, stays connected

@app.post("/control/start")
async def start_stream():
    # Sends {"command": "start"} to connected Pi

@app.post("/control/stop")
async def stop_stream():
    # Sends {"command": "stop"} to connected Pi

@app.get("/control/status")
async def status():
    return {"pi_connected": bool(pi_ws), "streaming": publisher_running}
```

## SCRIPTS.md — Project Script Documentation

### pi_publisher.py
- **Location:** /home/naman/pi_publisher.py
- **Status:** Active
- GStreamer pipeline → WebRTC → Janus → viewer
- Started/stopped by pi_control.py on command

### pi_control.py
- **Location:** /home/naman/pi_control.py
- **Status:** Active (runs via systemd on boot)
- Persistent WebSocket to EC2
- Receives: start, stop, status commands
- Sends: status updates

### main.py (EC2 FastAPI)
- **Location:** /home/ubuntu/app/main.py
- **Status:** Active
- Endpoints: /provision, /control/start, /control/stop, /control/status, /ws/pi-control

### pi1.html
- **Location:** /var/www/pi/pi1.html
- **Status:** Active production viewer
- Full dashboard: start/stop, WebRTC video, timer, detection log, clips viewer
- Accessed via secret URL (URL = credential)

### dashboard.html
- **Location:** /var/www/pi/dashboard.html
- **Status:** Obsolete/suspended
