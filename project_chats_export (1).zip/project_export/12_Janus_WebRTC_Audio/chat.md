# Janus WebRTC Full-Duplex Audio — Raspberry Pi 5 + AWS

**Date:** 2026-03-04  
**URL:** https://claude.ai/chat/6826d863-6058-46a0-beac-18a82876a57f

## Summary
Adding full-duplex two-way audio to an existing Janus VideoRoom WebRTC setup. Pi 5 USB mic → web browser, and web browser mic → Pi 5 Bluetooth speaker.

## Hardware
- **Audio capture (Pi):** USB Microphone
- **Audio playback (Pi):** Bluetooth Speaker
- **Janus plugin:** VideoRoom (already used for video)
- **Audio direction:** Full duplex (Pi ↔ Browser)

## Pi 5 Setup

### Bluetooth Speaker Pairing
```bash
bluetoothctl
  power on
  agent on
  scan on
  pair <SPEAKER_MAC>
  connect <SPEAKER_MAC>
  trust <SPEAKER_MAC>
  quit

# Set as default sink
pactl set-default-sink bluez_sink.<MAC_with_underscores>.a2dp_sink
```

### GStreamer Pipeline — Pi Mic → Janus
```bash
gst-launch-1.0 \
  pulsesrc device=alsa_input.usb-... ! \
  audio/x-raw,rate=48000,channels=1,format=S16LE ! \
  audioconvert ! audioresample ! \
  opusenc bitrate=64000 frame-size=20 ! \
  rtpopuspay pt=111 ! \
  udpsink host=127.0.0.1 port=5004
```

### Receive Browser Audio → Play on Bluetooth Speaker
```bash
gst-launch-1.0 \
  udpsrc port=5006 caps="application/x-rtp,media=audio,encoding-name=OPUS,payload=111" ! \
  rtpopusdepay ! opusdec ! audioconvert ! \
  pulsesink device=bluez_sink.<MAC>.a2dp_sink
```

## Janus Server (AWS EC2)

### VideoRoom Config (janus.plugin.videoroom.jcfg)
```
room-1234: {
    description = "360Secure Pi1 Room"
    is_private = false
    secret = "adminpwd"
    publishers = 2
    audiocodec = "opus"
    videocodec = "vp8"
    record = false
}
```

### NGINX Config for /pi1-audio
```nginx
location /pi1-audio {
    alias /var/www/pi/pi1-audio.html;
}
```

## Browser (pi1-audio.html) — Key Functions
```javascript
// Subscribe — hear Pi audio
janus.attach({
    plugin: "janus.plugin.videoroom",
    success: (pluginHandle) => {
        pluginHandle.send({ message: { request: "join", room: 1234, ptype: "subscriber" } });
    }
});

// Publish — browser mic to Pi
navigator.mediaDevices.getUserMedia({ audio: true })
    .then(stream => {
        pluginHandle.createOffer({ media: { audio: true, video: false } });
    });
```

## AWS Security Group Ports
| Protocol | Port Range | Purpose |
|----------|-----------|---------|
| UDP | 10000–60000 | WebRTC RTP/RTCP |
| TCP | 8088 | Janus HTTP API |
| TCP | 8089 | Janus HTTPS API |
| TCP | 8188 | Janus WebSocket |
| TCP | 443 | NGINX/HTTPS |

## Audio Quality Notes
- Bluetooth latency: 100–300ms (acceptable for intercom)
- Opus config: 20ms frame size, 64kbps
- Low latency tip: Use `a2dp_sink` profile, not `headset_head_unit`
