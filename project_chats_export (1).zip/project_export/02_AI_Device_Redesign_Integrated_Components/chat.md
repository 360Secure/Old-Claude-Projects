# AI device redesign with integrated components

**Date:** 2026-04-22  
**URL:** https://claude.ai/chat/7389950c-981a-42de-a41b-c9a796ff9e03

## Summary
Redesigning the AI Gate Keeper physical device to integrate: mic, speaker, small screen, camera, Pi Zero 2W, ESP32, rechargeable battery, and a custom manual lock mechanism.

## Manual Lock Design Spec
1. Lock keyhole located **behind bell** on front door side
2. **Steel shaft** routes from door eyehole through to lock inside
3. **Manual knob** inside door to open lock
4. **Power supply** routed through the steel shaft to outside unit

## Key Design Q&A
- Standard peephole: 12–14mm diameter — may need to enlarge to 20–25mm for shaft + wiring
- Shaft type options:
  - **Rotating** — turning knob → shaft → lock bolt
  - **Static** — structural rod only; lock actuated electronically
- Bell button cover options: slide/flip aside, hidden release, or removable cap
- Lock cylinder: standard pin tumbler (Euro profile / mortise) or custom small cylinder

## Components to Fit
- Microphone
- Speaker
- Small screen
- Camera
- Pi Zero 2W
- ESP32
- Rechargeable Battery
- Manual lock

---

## Power Management Architecture (Pi Zero 2W in wall panel)

### S2R (Suspend to RAM) Strategy
- Idle draw: ~20mA
- Wake time: < 2 seconds
- No SD card writes during normal operation → 8–10 year lifetime

### Always-On ESP8266 Wake Sources
All three funnel through ESP8266 → single GPIO wake pin on Pi:
1. mmWave motion detection
2. Bell button press
3. ESP-NOW command from lock box ESP32 (e.g. fingerprint)

### Auto-Suspend
- Implemented as systemd timer
- Resets on: camera activity, bell event, phone app connection
- Suspends after 60 seconds of no activity

### Power Draw Table
| Scenario | Wall panel draw |
|----------|-----------------|
| Pi in S2R + ESP8266 always-on | ~32mA |
| Pi fully active (visitor present) | ~450mA |
| Pi active avg (~10 min/hour) | ~107mA |

### Final Recommendation
```
Always on:     ESP8266 (~2mA) — handles ESP-NOW, mmWave, bell, GPIO wake
Suspended:     Pi Zero 2W (~20mA) — S2R, wakes in <2 seconds
Active:        Pi Zero 2W (~400–450mA) — camera, audio, Wi-Fi, app
Read-only FS:  SD card never written during normal operation
Auto-suspend:  60 seconds after last activity
```

## S2R Caveats
- Requires: Raspberry Pi OS Lite (64-bit), `echo mem > /sys/power/state`
- Some USB/camera peripherals may not restore cleanly after S2R
- One-time validation: test your camera module + ESP8266 GPIO combination
- Pin the specific kernel version that works reliably
