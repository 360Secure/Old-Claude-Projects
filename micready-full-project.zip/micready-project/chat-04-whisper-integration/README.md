# Chat 04 — Whisper Integration

## Problem discovered
The original app was sending audio to Claude directly via base64, but Claude's API doesn't process audio files — it was generating fictional analysis without hearing the voice.

## Solution implemented
Two-step pipeline:
1. **OpenAI Whisper API** (`whisper-1`) transcribes the audio to text ($0.006/min)
2. **Claude Sonnet** analyses the real transcript for genuine SWOT, comparison, and training

## Files updated
- `src/app/api/swot/route.ts` — added `transcribeAudio()` helper
- `src/app/api/compare/route.ts` — same
- `src/app/api/training/route.ts` — same

## Why not free Whisper?
User requested OpenAI Whisper API (they have a key). Local Whisper was considered but requires ~400MB RAM and Python setup on the server.

## env.local required
```
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
```
