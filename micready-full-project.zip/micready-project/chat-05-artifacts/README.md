# Chat 05 — Artifacts

## micready-standalone.html
A single-file version of the entire MicReady app that runs in any browser without a server.

- Uses the Anthropic API directly from the browser
- No backend required
- Set your `ANTHROPIC_API_KEY` in the `const ANTHROPIC_KEY = ''` line at the top of the script section
- All 4 features work: SWOT, Compare, Training, Progress

**Note:** The standalone version generates voice analysis without Whisper transcription (Claude doesn't receive the audio bytes directly — it generates contextually appropriate coaching feedback). For real transcription-based analysis, use the full Next.js app in `chat-02-rebuild-nextjs-app/`.
