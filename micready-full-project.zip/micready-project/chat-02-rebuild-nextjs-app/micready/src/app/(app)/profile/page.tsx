'use client';
export default function ProfilePage() {
  return (
    <div className="p-8 max-w-2xl mx-auto">
      <h1 className="font-serif text-3xl font-black text-ink mb-2">Profile</h1>
      <p className="text-muted mb-8">Your vocal coaching account.</p>
      <div className="p-6 rounded-2xl border border-border bg-cream space-y-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-ink flex items-center justify-center text-paper text-2xl font-serif font-black">M</div>
          <div>
            <div className="font-bold text-ink">MicReady User</div>
            <div className="text-sm text-muted">Voice coaching since April 2026</div>
          </div>
        </div>
        <hr className="border-border" />
        <div className="grid grid-cols-2 gap-4 text-sm">
          {[['Total Sessions', '4'], ['Best Score', '79/100'], ['Current Streak', '3 days'], ['Exercises Done', '12']].map(([k, v]) => (
            <div key={k}>
              <div className="text-muted">{k}</div>
              <div className="font-bold text-ink">{v}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
