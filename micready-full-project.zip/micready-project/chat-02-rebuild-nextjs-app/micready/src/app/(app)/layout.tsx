'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Mic, BarChart3, GitCompare, Dumbbell, TrendingUp, User } from 'lucide-react';

const navItems = [
  { href: '/', label: 'Dashboard', icon: BarChart3 },
  { href: '/swot-analysis', label: 'SWOT Analysis', icon: Mic },
  { href: '/comparative-analysis', label: 'Compare Voice', icon: GitCompare },
  { href: '/training', label: 'Training', icon: Dumbbell },
  { href: '/progress', label: 'Progress', icon: TrendingUp },
  { href: '/profile', label: 'Profile', icon: User },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <div className="flex min-h-screen bg-paper">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-cream flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <span className="font-serif text-2xl font-black text-ink">
            Mic<span className="text-gold">Ready</span>
          </span>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map(({ href, label, icon: Icon }) => {
            const active = pathname === href;
            return (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  active
                    ? 'bg-ink text-paper'
                    : 'text-muted hover:bg-border hover:text-ink'
                }`}
              >
                <Icon size={18} />
                {label}
              </Link>
            );
          })}
        </nav>
      </aside>
      {/* Main */}
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  );
}
