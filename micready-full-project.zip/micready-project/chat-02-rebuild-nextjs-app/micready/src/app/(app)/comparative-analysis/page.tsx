'use client';
import { useState } from 'react';
import { AudioInput } from '@/components/audio-input';

const SPEAKERS = ['Simon Sinek', 'Oprah Winfrey', 'Barack Obama', 'Brené Brown', 'Steve Jobs', 'Tony Robbins'];

interface CompareResult {
  overallSimilarity: number;
  dimensions: { name: string; userScore: number; speakerScore: number; feedback: string }[];
  keyDifferences: string[];
  actionableAdvice: string[];
  summary: string;
}

export default function ComparePage() {
  const [audio, setAudio] = useState<string | null>(null);
  const [speaker, setSpeaker] = useState(SPEAKERS[0]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CompareResult | null>(null);
  const [error, setError] = useState('');

  async function analyse() {
    if (!audio) return;
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ audioDataUri: audio, speakerName: speaker }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setResult(data);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Something went wrong');
    } finally { setLoading(false); }
  }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="font-serif text-3xl font-black text-ink mb-2">Compare Your Voice</h1>
      <p className="text-muted mb-8">See how your vocal style compares to world-class communicators.</p>

      <div className="p-6 rounded-2xl border border-border bg-cream mb-6 space-y-6">
        <div>
          <label className="block text-sm font-medium text-ink mb-2">Compare against</label>
          <select
            value={speaker}
            onChange={e => setSpeaker(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl border border-border bg-paper text-ink focus:outline-none focus:border-gold"
          >
            {SPEAKERS.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
        <AudioInput onAudioReady={setAudio} disabled={loading} />
        {audio && (
          <div className="flex justify-center">
            <button onClick={analyse} disabled={loading}
              className="px-8 py-3 bg-ink text-paper rounded-xl font-medium hover:bg-gold hover:text-ink transition-all disabled:opacity-50">
              {loading ? 'Comparing…' : 'Compare Now'}
            </button>
          </div>
        )}
      </div>

      {error && <p className="text-red-600 text-sm mb-4">{error}</p>}

      {result && (
        <div className="space-y-6">
          <div className="p-4 rounded-xl bg-ink text-paper flex items-center justify-between">
            <span>Similarity to {speaker}</span>
            <span className="font-serif text-3xl font-black text-gold">{result.overallSimilarity}%</span>
          </div>
          <p className="text-muted">{result.summary}</p>
          <div className="space-y-3">
            {result.dimensions.map(d => (
              <div key={d.name} className="p-4 rounded-xl border border-border bg-cream">
                <div className="flex justify-between mb-1">
                  <span className="font-medium text-sm">{d.name}</span>
                  <span className="text-xs text-muted">You: {d.userScore} / {speaker.split(' ')[0]}: {d.speakerScore}</span>
                </div>
                <div className="h-2 bg-border rounded-full overflow-hidden">
                  <div className="h-full bg-teal rounded-full" style={{ width: `${d.userScore}%` }} />
                </div>
                <p className="text-xs text-muted mt-2">{d.feedback}</p>
              </div>
            ))}
          </div>
          <div>
            <h3 className="font-bold mb-2">Actionable Advice</h3>
            <ul className="space-y-2">
              {result.actionableAdvice.map((a, i) => (
                <li key={i} className="text-sm text-muted flex gap-2"><span className="text-gold">→</span>{a}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
