'use client';
export default function ProgressPage() {
  const sessions = [
    { date: 'Apr 20', score: 62, label: 'First session' },
    { date: 'Apr 22', score: 68, label: 'SWOT Analysis' },
    { date: 'Apr 25', score: 74, label: 'Comparative' },
    { date: 'Apr 28', score: 79, label: 'Training focus' },
  ];

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="font-serif text-3xl font-black text-ink mb-2">Progress</h1>
      <p className="text-muted mb-8">Track your vocal improvement over time.</p>

      <div className="grid grid-cols-3 gap-4 mb-8">
        {[['Sessions', '4'], ['Avg Score', '71'], ['Improvement', '+17pts']].map(([label, value]) => (
          <div key={label} className="p-5 rounded-xl border border-border bg-cream text-center">
            <div className="font-serif text-2xl font-black text-gold">{value}</div>
            <div className="text-sm text-muted mt-1">{label}</div>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-2xl border border-border bg-cream">
        <h3 className="font-bold mb-4">Score History</h3>
        <div className="space-y-3">
          {sessions.map(s => (
            <div key={s.date} className="flex items-center gap-4">
              <span className="text-xs text-muted w-16">{s.date}</span>
              <div className="flex-1 h-8 bg-paper rounded-lg overflow-hidden relative">
                <div className="h-full bg-teal rounded-lg transition-all" style={{ width: `${s.score}%` }} />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-ink">{s.score}</span>
              </div>
              <span className="text-xs text-muted w-28 text-right">{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
