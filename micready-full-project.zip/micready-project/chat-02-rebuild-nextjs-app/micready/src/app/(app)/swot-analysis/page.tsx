'use client';
import { useState } from 'react';
import { AudioInput } from '@/components/audio-input';

interface SwotResult {
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
  overallScore: number;
  summary: string;
}

const quadrants = [
  { key: 'strengths', label: 'Strengths', color: 'bg-green-50 border-green-200 text-green-800' },
  { key: 'weaknesses', label: 'Weaknesses', color: 'bg-red-50 border-red-200 text-red-800' },
  { key: 'opportunities', label: 'Opportunities', color: 'bg-blue-50 border-blue-200 text-blue-800' },
  { key: 'threats', label: 'Threats', color: 'bg-amber-50 border-amber-200 text-amber-800' },
] as const;

export default function SwotPage() {
  const [audio, setAudio] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SwotResult | null>(null);
  const [error, setError] = useState('');

  async function analyse() {
    if (!audio) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/swot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ audioDataUri: audio }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setResult(data);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="font-serif text-3xl font-black text-ink mb-2">Voice SWOT Analysis</h1>
      <p className="text-muted mb-8">Record or upload a voice sample — Claude will analyse your vocal characteristics.</p>

      <div className="p-6 rounded-2xl border border-border bg-cream mb-6">
        <AudioInput onAudioReady={setAudio} disabled={loading} />
        {audio && (
          <div className="mt-4 flex justify-center">
            <button
              onClick={analyse}
              disabled={loading}
              className="px-8 py-3 bg-ink text-paper rounded-xl font-medium hover:bg-gold hover:text-ink transition-all disabled:opacity-50"
            >
              {loading ? 'Analysing…' : 'Analyse My Voice'}
            </button>
          </div>
        )}
      </div>

      {error && <p className="text-red-600 text-sm mb-4">{error}</p>}

      {result && (
        <div className="space-y-6">
          <div className="p-4 rounded-xl bg-ink text-paper flex items-center justify-between">
            <span className="font-medium">Overall Vocal Score</span>
            <span className="font-serif text-3xl font-black text-gold">{result.overallScore}<span className="text-lg">/100</span></span>
          </div>
          <p className="text-muted leading-relaxed">{result.summary}</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {quadrants.map(({ key, label, color }) => (
              <div key={key} className={`p-5 rounded-xl border ${color}`}>
                <h3 className="font-bold mb-3">{label}</h3>
                <ul className="space-y-1.5">
                  {result[key].map((item, i) => (
                    <li key={i} className="text-sm flex gap-2">
                      <span className="opacity-60">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
