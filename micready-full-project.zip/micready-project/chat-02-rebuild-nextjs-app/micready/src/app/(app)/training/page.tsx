'use client';
import { useState } from 'react';
import { AudioInput } from '@/components/audio-input';

interface Exercise { name: string; duration: string; description: string; benefit: string; }
interface Week { week: number; theme: string; exercises: Exercise[]; }
interface TrainingResult {
  focusAreas: string[];
  weeklyPlan: Week[];
  dailyHabits: string[];
  progressMarkers: string[];
  summary: string;
}

export default function TrainingPage() {
  const [audio, setAudio] = useState<string | null>(null);
  const [goals, setGoals] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TrainingResult | null>(null);
  const [error, setError] = useState('');

  async function generate() {
    if (!audio) return;
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/training', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ audioDataUri: audio, goals }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setResult(data);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Something went wrong');
    } finally { setLoading(false); }
  }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="font-serif text-3xl font-black text-ink mb-2">Training Plan</h1>
      <p className="text-muted mb-8">Get a personalised 4-week vocal training programme.</p>

      <div className="p-6 rounded-2xl border border-border bg-cream mb-6 space-y-6">
        <div>
          <label className="block text-sm font-medium text-ink mb-2">Your goals (optional)</label>
          <textarea
            value={goals}
            onChange={e => setGoals(e.target.value)}
            placeholder="e.g. Improve confidence in presentations, reduce filler words..."
            className="w-full px-4 py-3 rounded-xl border border-border bg-paper text-ink text-sm focus:outline-none focus:border-gold resize-none"
            rows={2}
          />
        </div>
        <AudioInput onAudioReady={setAudio} disabled={loading} />
        {audio && (
          <div className="flex justify-center">
            <button onClick={generate} disabled={loading}
              className="px-8 py-3 bg-ink text-paper rounded-xl font-medium hover:bg-gold hover:text-ink transition-all disabled:opacity-50">
              {loading ? 'Generating plan…' : 'Generate My Plan'}
            </button>
          </div>
        )}
      </div>

      {error && <p className="text-red-600 text-sm mb-4">{error}</p>}

      {result && (
        <div className="space-y-6">
          <p className="text-muted">{result.summary}</p>
          <div>
            <h3 className="font-bold mb-3">Focus Areas</h3>
            <div className="flex flex-wrap gap-2">
              {result.focusAreas.map((a, i) => (
                <span key={i} className="px-3 py-1 bg-ink text-paper text-xs rounded-full">{a}</span>
              ))}
            </div>
          </div>
          <div>
            <h3 className="font-bold mb-3">4-Week Plan</h3>
            <div className="space-y-4">
              {result.weeklyPlan.map(w => (
                <div key={w.week} className="p-5 rounded-xl border border-border bg-cream">
                  <h4 className="font-bold mb-3">Week {w.week} — {w.theme}</h4>
                  <div className="space-y-3">
                    {w.exercises.map((ex, i) => (
                      <div key={i} className="p-3 bg-paper rounded-lg">
                        <div className="flex justify-between mb-1">
                          <span className="font-medium text-sm">{ex.name}</span>
                          <span className="text-xs text-muted">{ex.duration}</span>
                        </div>
                        <p className="text-sm text-muted">{ex.description}</p>
                        <p className="text-xs text-teal mt-1">✓ {ex.benefit}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="font-bold mb-2">Daily Habits</h3>
            <ul className="space-y-1">
              {result.dailyHabits.map((h, i) => (
                <li key={i} className="text-sm text-muted flex gap-2"><span className="text-gold">•</span>{h}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
