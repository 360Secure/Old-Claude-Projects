import Link from 'next/link';
import { Mic, GitCompare, Dumbbell, TrendingUp } from 'lucide-react';

const features = [
  { href: '/swot-analysis', icon: Mic, title: 'SWOT Analysis', desc: 'AI-powered breakdown of your voice strengths, weaknesses, opportunities & threats.' },
  { href: '/comparative-analysis', icon: GitCompare, title: 'Compare Voice', desc: 'Measure your style against elite speakers like Simon Sinek or Oprah.' },
  { href: '/training', icon: Dumbbell, title: 'Training Plan', desc: 'Personalised exercises for breath control, articulation and confidence.' },
  { href: '/progress', icon: TrendingUp, title: 'Track Progress', desc: 'Visualise your vocal improvement across sessions over time.' },
];

export default function DashboardPage() {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="font-serif text-4xl font-black text-ink mb-2">Welcome back</h1>
      <p className="text-muted mb-10">Choose a feature to begin your voice coaching session.</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {features.map(({ href, icon: Icon, title, desc }) => (
          <Link
            key={href}
            href={href}
            className="group p-6 rounded-2xl border border-border bg-cream hover:border-gold hover:shadow-lg transition-all"
          >
            <div className="w-12 h-12 rounded-xl bg-ink flex items-center justify-center mb-4 group-hover:bg-gold transition-colors">
              <Icon size={22} className="text-paper" />
            </div>
            <h2 className="font-serif text-xl font-bold text-ink mb-1">{title}</h2>
            <p className="text-sm text-muted leading-relaxed">{desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
