import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'MicReady — AI Voice Coaching',
  description: 'Elevate your voice with AI-powered coaching and analysis',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
