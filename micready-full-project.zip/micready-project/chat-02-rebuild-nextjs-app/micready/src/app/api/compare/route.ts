import { NextRequest, NextResponse } from 'next/server';
import { callClaude, parseJSON } from '@/lib/anthropic';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function transcribeAudio(audioDataUri: string): Promise<string> {
  const match = audioDataUri.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) throw new Error('Invalid audio data URI');
  const [, mimeType, base64Data] = match;
  const buffer = Buffer.from(base64Data, 'base64');
  const ext = mimeType.includes('webm') ? 'webm' : 'mp3';
  const file = new File([buffer], `audio.${ext}`, { type: mimeType });
  const transcription = await openai.audio.transcriptions.create({ file, model: 'whisper-1' });
  return transcription.text;
}

const speakers = {
  'Simon Sinek': 'calm authority, storytelling, Why-framework, long pauses, inspirational tone',
  'Oprah Winfrey': 'warmth, empathy, emotional resonance, vulnerability, audience connection',
  'Barack Obama': 'measured cadence, gravitas, inclusive language, rhetorical rhythm',
  'Brené Brown': 'vulnerability, research-backed storytelling, conversational warmth, authenticity',
  'Steve Jobs': 'simplicity, dramatic pauses, theatrical reveals, minimalist clarity',
  'Tony Robbins': 'high energy, rapid fire delivery, physicality in voice, urgency, motivation',
};

export async function POST(req: NextRequest) {
  try {
    const { audioDataUri, speakerName } = await req.json();
    if (!audioDataUri || !speakerName) return NextResponse.json({ error: 'audioDataUri and speakerName required' }, { status: 400 });

    const transcript = await transcribeAudio(audioDataUri);
    const speakerStyle = speakers[speakerName as keyof typeof speakers] || speakerName;

    const system = `You are an expert voice coach who compares speakers to elite communicators. Respond with valid JSON only.`;
    const text = `Compare this speaker's transcript against ${speakerName}'s known style.

TRANSCRIPT: "${transcript}"
${speakerName}'s style: ${speakerStyle}

Respond with:
{
  "overallSimilarity": 65,
  "dimensions": [
    { "name": "Pacing", "userScore": 70, "speakerScore": 85, "feedback": "..." },
    { "name": "Confidence", "userScore": 60, "speakerScore": 95, "feedback": "..." },
    { "name": "Clarity", "userScore": 75, "speakerScore": 90, "feedback": "..." },
    { "name": "Emotional Depth", "userScore": 55, "speakerScore": 88, "feedback": "..." },
    { "name": "Storytelling", "userScore": 65, "speakerScore": 92, "feedback": "..." }
  ],
  "keyDifferences": ["...", "...", "..."],
  "actionableAdvice": ["...", "...", "..."],
  "summary": "..."
}`;

    const raw = await callClaude(system, [{ role: 'user', content: text }]);
    const result = parseJSON(raw);
    return NextResponse.json(result);
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
