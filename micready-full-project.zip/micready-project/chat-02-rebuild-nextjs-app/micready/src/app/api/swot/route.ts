import { NextRequest, NextResponse } from 'next/server';
import { callClaude, parseJSON } from '@/lib/anthropic';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function transcribeAudio(audioDataUri: string): Promise<string> {
  const match = audioDataUri.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) throw new Error('Invalid audio data URI');
  const [, mimeType, base64Data] = match;
  const buffer = Buffer.from(base64Data, 'base64');
  const ext = mimeType.includes('webm') ? 'webm' : mimeType.includes('mp4') ? 'mp4' : 'mp3';
  const file = new File([buffer], `audio.${ext}`, { type: mimeType });
  const transcription = await openai.audio.transcriptions.create({ file, model: 'whisper-1' });
  return transcription.text;
}

export async function POST(req: NextRequest) {
  try {
    const { audioDataUri } = await req.json();
    if (!audioDataUri) return NextResponse.json({ error: 'audioDataUri is required' }, { status: 400 });

    // Step 1: Transcribe with Whisper
    const transcript = await transcribeAudio(audioDataUri);

    // Step 2: Analyse with Claude
    const system = `You are an expert vocal coach and speech pathologist with 20 years of experience.
Analyse voice recordings based on their transcript and produce SWOT analyses.
Always respond with valid JSON only — no markdown, no explanation outside the JSON.`;

    const text = `Analyse this voice transcript and produce a professional SWOT analysis of the speaker's vocal characteristics.

TRANSCRIPT: "${transcript}"

Analyse: word choice, filler words, sentence structure, confidence indicators, pacing patterns, clarity, emotional delivery, articulation, and speech patterns evident in the text.

Respond with this exact JSON structure:
{
  "strengths": ["...", "...", "..."],
  "weaknesses": ["...", "...", "..."],
  "opportunities": ["...", "...", "..."],
  "threats": ["...", "...", "..."],
  "overallScore": 72,
  "summary": "2-3 sentence overall assessment"
}`;

    const raw = await callClaude(system, [{ role: 'user', content: text }]);
    const result = parseJSON(raw);
    return NextResponse.json(result);
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
