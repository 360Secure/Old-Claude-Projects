import { NextRequest, NextResponse } from 'next/server';
import { callClaude, parseJSON } from '@/lib/anthropic';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function transcribeAudio(audioDataUri: string): Promise<string> {
  const match = audioDataUri.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) throw new Error('Invalid audio data URI');
  const [, mimeType, base64Data] = match;
  const buffer = Buffer.from(base64Data, 'base64');
  const ext = mimeType.includes('webm') ? 'webm' : 'mp3';
  const file = new File([buffer], `audio.${ext}`, { type: mimeType });
  const transcription = await openai.audio.transcriptions.create({ file, model: 'whisper-1' });
  return transcription.text;
}

export async function POST(req: NextRequest) {
  try {
    const { audioDataUri, goals } = await req.json();
    if (!audioDataUri) return NextResponse.json({ error: 'audioDataUri required' }, { status: 400 });

    const transcript = await transcribeAudio(audioDataUri);

    const system = `You are a world-class vocal coach creating personalised training plans. Respond with valid JSON only.`;
    const text = `Create a personalised 4-week vocal training plan for this speaker.

TRANSCRIPT: "${transcript}"
GOALS: ${goals || 'Improve overall vocal presence and confidence'}

Respond with:
{
  "focusAreas": ["...", "..."],
  "weeklyPlan": [
    {
      "week": 1,
      "theme": "Foundation",
      "exercises": [
        { "name": "...", "duration": "5 mins", "description": "...", "benefit": "..." }
      ]
    }
  ],
  "dailyHabits": ["...", "..."],
  "progressMarkers": ["...", "..."],
  "summary": "..."
}`;

    const raw = await callClaude(system, [{ role: 'user', content: text }]);
    const result = parseJSON(raw);
    return NextResponse.json(result);
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
