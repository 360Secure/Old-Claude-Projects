'use client';
import { useState, useRef } from 'react';
import { Mic, Square, Upload } from 'lucide-react';

interface AudioInputProps {
  onAudioReady: (dataUri: string) => void;
  disabled?: boolean;
}

export function AudioInput({ onAudioReady, disabled }: AudioInputProps) {
  const [recording, setRecording] = useState(false);
  const [recorded, setRecorded] = useState(false);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  async function startRecording() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mr = new MediaRecorder(stream);
    chunksRef.current = [];
    mr.ondataavailable = (e) => chunksRef.current.push(e.data);
    mr.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
      const reader = new FileReader();
      reader.onload = () => onAudioReady(reader.result as string);
      reader.readAsDataURL(blob);
      setRecorded(true);
      stream.getTracks().forEach(t => t.stop());
    };
    mr.start();
    mediaRef.current = mr;
    setRecording(true);
  }

  function stopRecording() {
    mediaRef.current?.stop();
    setRecording(false);
  }

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => onAudioReady(reader.result as string);
    reader.readAsDataURL(file);
    setRecorded(true);
  }

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex gap-3">
        {!recording ? (
          <button
            onClick={startRecording}
            disabled={disabled}
            className="flex items-center gap-2 px-6 py-3 bg-ink text-paper rounded-xl font-medium hover:bg-gold hover:text-ink transition-all disabled:opacity-50"
          >
            <Mic size={18} /> Record Voice
          </button>
        ) : (
          <button
            onClick={stopRecording}
            className="flex items-center gap-2 px-6 py-3 bg-red-600 text-white rounded-xl font-medium animate-pulse"
          >
            <Square size={18} /> Stop Recording
          </button>
        )}
        <button
          onClick={() => fileRef.current?.click()}
          disabled={disabled || recording}
          className="flex items-center gap-2 px-6 py-3 border border-border rounded-xl font-medium text-muted hover:text-ink hover:border-ink transition-all disabled:opacity-50"
        >
          <Upload size={18} /> Upload File
        </button>
      </div>
      <input ref={fileRef} type="file" accept="audio/*" className="hidden" onChange={handleFile} />
      {recorded && !recording && (
        <p className="text-sm text-teal font-medium">✓ Audio ready — click Analyse below</p>
      )}
    </div>
  );
}
