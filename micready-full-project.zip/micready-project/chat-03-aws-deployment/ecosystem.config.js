module.exports = {
  apps: [{
    name: 'micready',
    script: 'node_modules/.bin/next',
    args: 'start -p 3000',
    cwd: '/var/www/micready',
    env: { NODE_ENV: 'production', PORT: 3000 },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: '/var/log/pm2/micready-error.log',
    out_file: '/var/log/pm2/micready-out.log',
  }]
};
