# MicReady — AWS Deployment Guide
## Domain: micready.360secure.in

---

## Prerequisites
- Ubuntu 22.04 LTS EC2 instance
- Ports 22, 80, 443 open in Security Group
- DNS: `micready.360secure.in` A-record → your EC2 public IP

---

## Step 1 — Upload project from your local machine

```bash
# On your local machine:
scp -i 360secure.pem micready.zip ubuntu@YOUR_EC2_IP:/home/ubuntu/
ssh -i 360secure.pem ubuntu@YOUR_EC2_IP
```

## Step 2 — Install dependencies on server

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs nginx
sudo npm install -g pm2
```

## Step 3 — Set up app

```bash
sudo mkdir -p /var/www/micready
sudo chown ubuntu:ubuntu /var/www/micready
cd /var/www/micready
unzip /home/ubuntu/micready.zip
mv micready/* micready/.* . 2>/dev/null || true
rmdir micready 2>/dev/null || true

# Set API keys
nano .env.local
# Add: ANTHROPIC_API_KEY=sk-ant-...
# Add: OPENAI_API_KEY=sk-...

npm install
npm run build
```

## Step 4 — Configure Nginx

```bash
sudo cp nginx.conf /etc/nginx/sites-available/micready
sudo ln -s /etc/nginx/sites-available/micready /etc/nginx/sites-enabled/micready
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl restart nginx
```

## Step 5 — SSL

```bash
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d micready.360secure.in
```

## Step 6 — Start with PM2

```bash
sudo mkdir -p /var/log/pm2 && sudo chown ubuntu:ubuntu /var/log/pm2
pm2 start ecosystem.config.js
pm2 save
pm2 startup   # run the command it outputs
```

## Common commands

```bash
pm2 logs micready          # Live logs
pm2 restart micready       # Restart
pm2 status                 # Health check
sudo tail -f /var/log/nginx/error.log

# After updating code:
npm run build && pm2 restart micready
```

## Troubleshooting

| Problem | Fix |
|---|---|
| 502 Bad Gateway | PM2 not running — `pm2 restart micready` |
| API calls fail (500) | Check `ANTHROPIC_API_KEY` in `.env.local` |
| SSL cert errors | Re-run `sudo certbot --nginx -d micready.360secure.in` |
| Build fails (PostCSS) | Check `postcss.config.mjs` exists |
