# IELTS Preparation Website — Version 1

**Chat URL:** https://claude.ai/chat/d274389a-6a03-4834-9697-4969d548c8a6  
**Date:** March 14, 2026  

## Description
First version of a comprehensive static HTML/CSS IELTS preparation website.
Focused primarily on Writing and Speaking sections.

### Features
- Professional design with Playfair Display + DM Sans fonts
- Writing Module: Task 1 (Academic & GT), Task 2 Essays
- Speaking Module: Part 1, 2, 3 formats with cue cards
- Sample answers with band scores
- Tips & strategies for each section
- Chemistry/Solutions notes integration (KCET exam content)

## Files
- `ielts-v1.html` — Main static HTML site

## How to Use
Open `ielts-v1.html` directly in any web browser — no server needed.
