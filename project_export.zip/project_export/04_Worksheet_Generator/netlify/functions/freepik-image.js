const FREEPIK_KEY = process.env.FREEPIK_API_KEY || '';

exports.handler = async (event) => {
  const { query } = event.queryStringParameters || {};
  if (!query) return { statusCode: 400, body: 'Missing query' };
  
  try {
    const response = await fetch(
      `https://api.freepik.com/v1/resources?locale=en-US&page=1&limit=1&order=relevance&term=${encodeURIComponent(query)}&filters[content_type][photo]=1`,
      { headers: { 'X-Freepik-API-Key': FREEPIK_KEY } }
    );
    const data = await response.json();
    const imageUrl = data?.data?.[0]?.image?.source?.url || null;
    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify({ imageUrl })
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
