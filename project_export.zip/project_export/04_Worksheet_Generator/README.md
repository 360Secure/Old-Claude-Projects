# AI-Powered Worksheet Generator

**Chat URL:** https://claude.ai/chat/dbe43159-f948-465e-8374-5e37f82942a1  
**Date:** April 17, 2026  

## Description
A two-panel website that uses the Groq API to generate educational worksheets.

### Features
- Left panel: Upload info file, set subject/grade/topic/difficulty/question count/type
- Right panel: Generated worksheet with interactive answer fields
- PDF download of completed worksheet
- Freepik API integration for educational images
- Netlify serverless function for image proxy

### Difficulty Levels
- Beginner / Intermediate / Advanced / Professional

### Question Types
- Multiple Choice, Short Answer, Fill in the Blank, True/False, Essay

## Files
- `worksheet-generator.html` — Main standalone HTML (uses Groq API directly)
- `netlify/functions/freepik-image.js` — Serverless image proxy function
- `netlify.toml` — Netlify deployment config

## Setup
1. Open `worksheet-generator.html` in browser
2. Enter your Groq API key (get free key at console.groq.com)
3. Fill in worksheet parameters and click Generate

## Deploy to Netlify (for image support)
1. Drag the `worksheet-site` folder to netlify.com/drop
2. Set environment variable: `FREEPIK_API_KEY=your_key`
