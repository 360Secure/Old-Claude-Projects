# Math Is Fun — Testing Platform

**Chat URL:** https://claude.ai/chat/4a82a81c-3fd8-49a9-8cc1-d26b1561e62d  
**Date:** March 15, 2026  

## Description
A comprehensive React-based math testing platform for Grades 1–10.

### Features
- Grade-isolated question banks (Grades 1–10, zero overlap)
- Three difficulty levels: Easy / Medium / Hard
- Topic tags on every question (e.g. "Fractions", "Trigonometry")
- Question count displayed on selection screen
- Grade curriculum preview before selecting difficulty
- Live scoring and countdown timer
- Animated UI with Fredoka One + Nunito fonts

## Files
- `MathIsFun.jsx` — Complete React component

## How to Run
1. `npx create-react-app mathisfun && cd mathisfun`
2. Replace `src/App.js` content with `MathIsFun.jsx`
3. `npm start`

Or paste into [stackblitz.com](https://stackblitz.com) → New React Project instantly.
