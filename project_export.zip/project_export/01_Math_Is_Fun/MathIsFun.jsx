import { useState, useEffect, useRef } from "react";

// ============================================================
// MATH IS FUN — Grade-Isolated Testing Platform
// Grades 1-10 | Easy / Medium / Hard | Topic-tagged questions
// ============================================================

const COLORS = {
  navy: "#0a0f2c", navyLight: "#131a3e", navyMid: "#1a2456",
  yellow: "#FFD93D", yellowDark: "#e6c235", teal: "#06d6a0",
  tealDark: "#04a57d", coral: "#ff6b6b", purple: "#845ef7",
  blue: "#339af0", white: "#ffffff", offWhite: "#f0f4ff",
  gray: "#8892b0", grayLight: "#ccd6f6", cardBg: "#1a2456",
  cardBorder: "#2a3570",
};

// Grade-isolated question banks
const QB = {
  1: {
    easy: [
      { q: "2 + 3 = ?", opts: ["4","5","6","7"], ans: 1, topic: "Addition" },
      { q: "5 - 2 = ?", opts: ["2","3","4","5"], ans: 1, topic: "Subtraction" },
      { q: "How many sides does a triangle have?", opts: ["2","3","4","5"], ans: 1, topic: "Shapes" },
      { q: "1 + 1 = ?", opts: ["1","2","3","4"], ans: 1, topic: "Addition" },
      { q: "Count: ★★★★ = ?", opts: ["3","4","5","6"], ans: 1, topic: "Counting" },
    ],
    medium: [
      { q: "7 + 8 = ?", opts: ["13","14","15","16"], ans: 2, topic: "Addition" },
      { q: "10 - 4 = ?", opts: ["5","6","7","8"], ans: 1, topic: "Subtraction" },
      { q: "3 × 2 = ?", opts: ["4","5","6","7"], ans: 2, topic: "Multiplication" },
      { q: "What comes after 19?", opts: ["18","20","21","22"], ans: 1, topic: "Counting" },
    ],
    hard: [
      { q: "15 - 9 = ?", opts: ["5","6","7","8"], ans: 1, topic: "Subtraction" },
      { q: "4 × 3 = ?", opts: ["10","11","12","13"], ans: 2, topic: "Multiplication" },
      { q: "Half of 20 = ?", opts: ["8","9","10","11"], ans: 2, topic: "Division" },
    ],
  },
  2: {
    easy: [
      { q: "12 + 8 = ?", opts: ["18","19","20","21"], ans: 2, topic: "Addition" },
      { q: "25 - 10 = ?", opts: ["13","14","15","16"], ans: 2, topic: "Subtraction" },
      { q: "5 × 4 = ?", opts: ["18","19","20","21"], ans: 2, topic: "Multiplication" },
    ],
    medium: [
      { q: "3 × 7 = ?", opts: ["19","20","21","22"], ans: 2, topic: "Multiplication" },
      { q: "48 ÷ 6 = ?", opts: ["6","7","8","9"], ans: 2, topic: "Division" },
      { q: "Round 47 to nearest 10:", opts: ["40","45","50","60"], ans: 2, topic: "Rounding" },
    ],
    hard: [
      { q: "99 - 47 = ?", opts: ["50","51","52","53"], ans: 2, topic: "Subtraction" },
      { q: "6 × 8 = ?", opts: ["42","44","46","48"], ans: 3, topic: "Multiplication" },
    ],
  },
  3: {
    easy: [
      { q: "½ of 40 = ?", opts: ["15","20","25","30"], ans: 1, topic: "Fractions" },
      { q: "Perimeter of square, side=5:", opts: ["15","20","25","30"], ans: 1, topic: "Geometry" },
      { q: "100 × 3 = ?", opts: ["300","30","3000","310"], ans: 0, topic: "Multiplication" },
    ],
    medium: [
      { q: "¼ of 80 = ?", opts: ["15","20","25","30"], ans: 1, topic: "Fractions" },
      { q: "Area of rectangle 6×4:", opts: ["20","22","24","26"], ans: 2, topic: "Area" },
    ],
    hard: [
      { q: "123 × 4 = ?", opts: ["482","490","492","502"], ans: 2, topic: "Multiplication" },
      { q: "Find the pattern: 2,4,8,16,__", opts: ["24","28","32","36"], ans: 2, topic: "Patterns" },
    ],
  },
  4: {
    easy: [
      { q: "LCM of 4 and 6:", opts: ["8","10","12","14"], ans: 2, topic: "LCM/HCF" },
      { q: "HCF of 12 and 18:", opts: ["4","6","8","10"], ans: 1, topic: "LCM/HCF" },
    ],
    medium: [
      { q: "2/3 + 1/3 = ?", opts: ["2/3","3/3","4/3","1"], ans: 3, topic: "Fractions" },
      { q: "20% of 200 = ?", opts: ["30","35","40","45"], ans: 2, topic: "Percentages" },
    ],
    hard: [
      { q: "3/4 × 2/5 = ?", opts: ["5/9","6/20","6/9","5/20"], ans: 1, topic: "Fractions" },
      { q: "If 5x = 35, x = ?", opts: ["5","6","7","8"], ans: 2, topic: "Algebra" },
    ],
  },
  5: {
    easy: [
      { q: "√25 = ?", opts: ["3","4","5","6"], ans: 2, topic: "Square Roots" },
      { q: "2³ = ?", opts: ["5","6","7","8"], ans: 3, topic: "Exponents" },
    ],
    medium: [
      { q: "Simple interest: P=1000, R=5%, T=2yr", opts: ["50","75","100","125"], ans: 2, topic: "SI" },
      { q: "x + 7 = 15, x = ?", opts: ["6","7","8","9"], ans: 2, topic: "Algebra" },
    ],
    hard: [
      { q: "Volume of cube, side=3:", opts: ["9","18","27","36"], ans: 2, topic: "Volume" },
      { q: "2x + 3 = 11, x = ?", opts: ["2","3","4","5"], ans: 2, topic: "Algebra" },
    ],
  },
  6: {
    easy: [
      { q: "Integers: -5 + 8 = ?", opts: ["1","2","3","4"], ans: 2, topic: "Integers" },
      { q: "Ratio 2:3 of 30:", opts: ["10 and 20","12 and 18","15 and 15","8 and 22"], ans: 1, topic: "Ratio" },
    ],
    medium: [
      { q: "25% of 400 = ?", opts: ["75","100","125","150"], ans: 1, topic: "Percentages" },
      { q: "3x - 4 = 11, x = ?", opts: ["4","5","6","7"], ans: 1, topic: "Algebra" },
    ],
    hard: [
      { q: "Speed=60km/h, Time=2.5h, Distance=?", opts: ["120","140","150","160"], ans: 2, topic: "Speed" },
      { q: "Mode of: 2,3,3,4,5,3,6:", opts: ["2","3","4","5"], ans: 1, topic: "Statistics" },
    ],
  },
  7: {
    easy: [
      { q: "20% of 500 = ?", opts: ["80","90","100","110"], ans: 2, topic: "Percentages" },
      { q: "Find x: 4x = 28", opts: ["5","6","7","8"], ans: 2, topic: "Algebra" },
    ],
    medium: [
      { q: "Profit%: CP=200, SP=240", opts: ["15%","20%","25%","30%"], ans: 1, topic: "Profit/Loss" },
      { q: "Mean of 4,7,8,9,12:", opts: ["7","8","9","10"], ans: 1, topic: "Statistics" },
    ],
    hard: [
      { q: "Compound interest annually: P=1000,R=10%,T=2yr", opts: ["200","205","210","215"], ans: 2, topic: "Compound Interest" },
      { q: "Exterior angle of regular hexagon:", opts: ["45°","50°","60°","70°"], ans: 2, topic: "Geometry" },
    ],
  },
  8: {
    easy: [
      { q: "x² = 64, x = ?", opts: ["6","7","8","9"], ans: 2, topic: "Quadratics" },
      { q: "Slope of y=3x+2:", opts: ["1","2","3","4"], ans: 2, topic: "Linear Equations" },
    ],
    medium: [
      { q: "Pythagoras: legs 3,4; hypotenuse=?", opts: ["4","5","6","7"], ans: 1, topic: "Pythagoras" },
      { q: "(x+2)(x-2) = ?", opts: ["x²-2","x²-4","x²+4","x²-8"], ans: 1, topic: "Algebra" },
    ],
    hard: [
      { q: "Solve: 2x²=8, x=?", opts: ["±1","±2","±3","±4"], ans: 1, topic: "Quadratics" },
      { q: "Volume of cylinder r=3,h=7 (π≈22/7):", opts: ["188","196","198","200"], ans: 2, topic: "Volume" },
    ],
  },
  9: {
    easy: [
      { q: "sin 30° = ?", opts: ["0.5","√2/2","√3/2","1"], ans: 0, topic: "Trigonometry" },
      { q: "cos 90° = ?", opts: ["1","0.5","0","-1"], ans: 2, topic: "Trigonometry" },
    ],
    medium: [
      { q: "Distance: (0,0) to (3,4):", opts: ["4","5","6","7"], ans: 1, topic: "Coordinate Geometry" },
      { q: "tan 45° = ?", opts: ["0","0.5","1","√3"], ans: 2, topic: "Trigonometry" },
    ],
    hard: [
      { q: "Probability of head in 3 tosses all heads:", opts: ["1/4","1/6","1/8","1/16"], ans: 2, topic: "Probability" },
      { q: "Sum of AP 1+3+5+...+19:", opts: ["90","95","100","105"], ans: 2, topic: "Sequences" },
    ],
  },
  10: {
    easy: [
      { q: "Value of sin²θ + cos²θ:", opts: ["0","0.5","1","2"], ans: 2, topic: "Trigonometry" },
      { q: "Roots of x²-5x+6=0:", opts: ["1,6","2,3","3,4","2,4"], ans: 1, topic: "Quadratics" },
    ],
    medium: [
      { q: "HCF of polynomials x²-4 and x²-x-2:", opts: ["x-2","x+2","x-1","x+1"], ans: 0, topic: "Polynomials" },
      { q: "If speed doubles, time halves — distance?", opts: ["Halves","Stays same","Doubles","Quadruples"], ans: 1, topic: "Speed-Distance" },
    ],
    hard: [
      { q: "Discriminant of 2x²-7x+3:", opts: ["25","30","49","25"], ans: 0, topic: "Quadratics" },
      { q: "Number of real solutions: x²+1=0:", opts: ["0","1","2","Infinite"], ans: 0, topic: "Real Numbers" },
    ],
  },
};

const GRADE_INFO = {
  1: { emoji:"🌱", color:"#FFD93D", topics:["Counting","Addition","Subtraction","Shapes"] },
  2: { emoji:"🌿", color:"#06d6a0", topics:["Addition","Multiplication","Division","Rounding"] },
  3: { emoji:"🌳", color:"#339af0", topics:["Fractions","Area","Patterns","Geometry"] },
  4: { emoji:"⭐", color:"#845ef7", topics:["LCM/HCF","Fractions","Percentages","Algebra"] },
  5: { emoji:"🔥", color:"#ff6b6b", topics:["Square Roots","Exponents","SI","Volume"] },
  6: { emoji:"💎", color:"#20c997", topics:["Integers","Ratio","Percentages","Speed"] },
  7: { emoji:"🚀", color:"#f03e3e", topics:["Profit/Loss","Statistics","CI","Geometry"] },
  8: { emoji:"⚡", color:"#f59f00", topics:["Quadratics","Pythagoras","Algebra","Volume"] },
  9: { emoji:"🎯", color:"#cc5de8", topics:["Trigonometry","Coordinate Geom","Probability","Sequences"] },
 10: { emoji:"👑", color:"#e64980", topics:["Advanced Trig","Polynomials","Real Numbers","Quadratics"] },
};

export default function MathIsFun({ initGrade = null }) {
  const [page, setPage] = useState("home"); // home | select | test | result
  const [grade, setGrade] = useState(initGrade);
  const [difficulty, setDifficulty] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState(null);
  const [showAns, setShowAns] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);
  const timerRef = useRef(null);

  useEffect(() => {
    if (initGrade) setPage("select");
  }, [initGrade]);

  const startTest = (g, d) => {
    const pool = QB[g][d] || [];
    const shuffled = [...pool].sort(() => Math.random() - 0.5).slice(0, 10);
    setQuestions(shuffled);
    setGrade(g); setDifficulty(d);
    setCurrent(0); setScore(0); setSelected(null); setShowAns(false);
    setTimeLeft(30);
    setPage("test");
  };

  useEffect(() => {
    if (page !== "test") return;
    timerRef.current = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) { clearInterval(timerRef.current); handleNext(true); return 30; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, [page, current]);

  const handleAnswer = (i) => {
    if (showAns) return;
    clearInterval(timerRef.current);
    setSelected(i);
    setShowAns(true);
    if (i === questions[current].ans) setScore(s => s + 1);
  };

  const handleNext = (auto = false) => {
    if (!auto && !showAns) return;
    clearInterval(timerRef.current);
    if (current + 1 >= questions.length) { setPage("result"); return; }
    setCurrent(c => c + 1);
    setSelected(null); setShowAns(false); setTimeLeft(30);
  };

  const gi = grade ? GRADE_INFO[grade] : null;

  const styles = {
    app: { minHeight:"100vh", background:"#0a0f2c", color:"#fff", fontFamily:"'Nunito',sans-serif" },
    btn: (bg="#FFD93D",color="#0a0f2c") => ({
      background:bg, color, border:"none", borderRadius:12, padding:"12px 28px",
      fontWeight:800, fontSize:16, cursor:"pointer", fontFamily:"inherit"
    }),
  };

  if (page === "home") return (
    <div style={styles.app}>
      <div style={{textAlign:"center",padding:"60px 20px"}}>
        <div style={{fontSize:64}}>🧮</div>
        <h1 style={{fontFamily:"'Fredoka One',cursive",fontSize:52,color:"#FFD93D",margin:"16px 0"}}>Math Is Fun!</h1>
        <p style={{fontSize:20,color:"#ccd6f6",marginBottom:40}}>Grade-isolated tests for Grades 1–10</p>
        <button style={styles.btn()} onClick={() => setPage("select")}>Start Practice →</button>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:12,padding:"0 20px 40px",maxWidth:800,margin:"0 auto"}}>
        {Object.entries(GRADE_INFO).map(([g, info]) => (
          <div key={g} onClick={() => { setGrade(+g); setPage("select"); }}
            style={{background:"#1a2456",border:`2px solid ${info.color}`,borderRadius:14,
              padding:"16px 8px",textAlign:"center",cursor:"pointer"}}>
            <div style={{fontSize:28}}>{info.emoji}</div>
            <div style={{fontWeight:800,color:info.color}}>Grade {g}</div>
            <div style={{fontSize:11,color:"#8892b0",marginTop:4}}>{info.topics.slice(0,2).join(" • ")}</div>
          </div>
        ))}
      </div>
    </div>
  );

  if (page === "select") return (
    <div style={{...styles.app,padding:30}}>
      <button onClick={() => setPage("home")} style={{...styles.btn("#1a2456","#fff"),marginBottom:24}}>← Back</button>
      <h2 style={{fontFamily:"'Fredoka One',cursive",fontSize:36,color:"#FFD93D",marginBottom:8}}>
        {grade ? `Grade ${grade} ${GRADE_INFO[grade].emoji}` : "Select Grade"}
      </h2>
      {grade && <p style={{color:"#8892b0",marginBottom:24}}>{GRADE_INFO[grade].topics.join(" • ")}</p>}
      {!grade && (
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(120px,1fr))",gap:10,marginBottom:30}}>
          {Object.entries(GRADE_INFO).map(([g, info]) => (
            <button key={g} onClick={() => setGrade(+g)}
              style={{...styles.btn(info.color,"#0a0f2c"),fontSize:14}}>
              {info.emoji} Grade {g}
            </button>
          ))}
        </div>
      )}
      {grade && (
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:16}}>
          {["easy","medium","hard"].map(d => (
            <div key={d} onClick={() => startTest(grade, d)}
              style={{background:"#1a2456",border:"2px solid #2a3570",borderRadius:16,padding:24,cursor:"pointer",textAlign:"center"}}>
              <div style={{fontSize:36}}>{d==="easy"?"🟢":d==="medium"?"🟡":"🔴"}</div>
              <div style={{fontFamily:"'Fredoka One',cursive",fontSize:24,color:"#FFD93D",textTransform:"capitalize",margin:"8px 0"}}>{d}</div>
              <div style={{color:"#8892b0",fontSize:13}}>{QB[grade][d]?.length || 0} questions</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  if (page === "test" && questions.length > 0) {
    const q = questions[current];
    return (
      <div style={{...styles.app,padding:30,maxWidth:600,margin:"0 auto"}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:20}}>
          <span style={{color:"#FFD93D",fontWeight:800}}>{current+1}/{questions.length}</span>
          <span style={{color:timeLeft<10?"#ff6b6b":"#06d6a0",fontWeight:800}}>⏱ {timeLeft}s</span>
          <span style={{color:"#ccd6f6"}}>Score: {score}</span>
        </div>
        <div style={{height:4,background:"#1a2456",borderRadius:2,marginBottom:30}}>
          <div style={{height:"100%",width:`${((current)/questions.length)*100}%`,background:"#FFD93D",borderRadius:2}} />
        </div>
        <div style={{background:"#1a2456",borderRadius:16,padding:24,marginBottom:20}}>
          <div style={{fontSize:12,color:"#8892b0",marginBottom:8}}>📚 {q.topic}</div>
          <div style={{fontSize:22,fontWeight:700}}>{q.q}</div>
        </div>
        <div style={{display:"grid",gap:10}}>
          {q.opts.map((opt, i) => {
            let bg = "#1a2456", border = "#2a3570";
            if (showAns) {
              if (i === q.ans) { bg="#0d4a2e"; border="#06d6a0"; }
              else if (i === selected && i !== q.ans) { bg="#4a1a1a"; border="#ff6b6b"; }
            } else if (i === selected) { bg="#2a3570"; border="#FFD93D"; }
            return (
              <button key={i} onClick={() => handleAnswer(i)}
                style={{background:bg,border:`2px solid ${border}`,borderRadius:12,
                  padding:"14px 20px",color:"#fff",fontFamily:"inherit",fontWeight:600,
                  fontSize:16,cursor:"pointer",textAlign:"left"}}>
                {["A","B","C","D"][i]}. {opt}
              </button>
            );
          })}
        </div>
        {showAns && (
          <button onClick={handleNext} style={{...styles.btn(),width:"100%",marginTop:20,fontSize:18}}>
            {current+1 >= questions.length ? "See Results" : "Next →"}
          </button>
        )}
      </div>
    );
  }

  if (page === "result") return (
    <div style={{...styles.app,textAlign:"center",padding:40}}>
      <div style={{fontSize:72}}>{score >= questions.length*0.8 ? "🏆" : score >= questions.length*0.5 ? "⭐" : "💪"}</div>
      <h2 style={{fontFamily:"'Fredoka One',cursive",fontSize:48,color:"#FFD93D",margin:"16px 0"}}>
        {score}/{questions.length}
      </h2>
      <p style={{fontSize:20,color:"#ccd6f6",marginBottom:40}}>
        {score >= questions.length*0.8 ? "Excellent! 🎉" : score >= questions.length*0.5 ? "Good job! 👍" : "Keep practicing! 💪"}
      </p>
      <div style={{display:"flex",gap:16,justifyContent:"center",flexWrap:"wrap"}}>
        <button style={styles.btn()} onClick={() => startTest(grade, difficulty)}>Try Again</button>
        <button style={styles.btn("#1a2456","#fff")} onClick={() => setPage("select")}>Change Level</button>
        <button style={styles.btn("#2a3570","#fff")} onClick={() => setPage("home")}>Home</button>
      </div>
    </div>
  );

  return null;
}
