# Project Export — All Chats & Artifacts

**Exported:** April 28, 2026  
**Total Chats:** 6

---

## 📁 Folder Structure

```
project_export/
├── PROJECT_INDEX.md          ← This file
├── 01_Math_Is_Fun/
│   ├── README.md
│   └── MathIsFun.jsx         ← React testing platform (Grades 1–10)
├── 02_IELTS_Website_v1/
│   ├── README.md
│   └── ielts-v1.html         ← IELTS prep site (Writing + Speaking)
├── 03_IELTS_Website_v2/
│   ├── README.md
│   └── ielts-v2-enhanced.html ← Enhanced with GT Letter Writing module
├── 04_Worksheet_Generator/
│   ├── README.md
│   ├── worksheet-generator.html ← AI worksheet generator (Groq API)
│   ├── netlify.toml
│   └── netlify/functions/
│       └── freepik-image.js  ← Serverless image proxy
├── 05_BrainGym360/
│   ├── README.md
│   ├── DEPLOYMENT.md         ← AWS server deployment guide
│   └── braingym360-homepage.html ← Interactive homepage preview
└── 06_Project_File_Visibility/
    └── README.md             ← Meta chat (no artifacts)
```

---

## 🔗 Chat Links

| # | Project | Chat URL | Date |
|---|---------|----------|------|
| 1 | Math Is Fun | https://claude.ai/chat/4a82a81c-3fd8-49a9-8cc1-d26b1561e62d | Mar 15, 2026 |
| 2 | IELTS Website v1 | https://claude.ai/chat/d274389a-6a03-4834-9697-4969d548c8a6 | Mar 14, 2026 |
| 3 | IELTS Website v2 | https://claude.ai/chat/909dfc39-f374-4e47-815f-e0fab381d985 | Apr 22, 2026 |
| 4 | Worksheet Generator | https://claude.ai/chat/dbe43159-f948-465e-8374-5e37f82942a1 | Apr 17, 2026 |
| 5 | BrainGym360 | https://claude.ai/chat/fb416a01-0390-40ea-b7e0-5aaa247a991b | Apr 26, 2026 |
| 6 | Project File Visibility | https://claude.ai/chat/47f49e80-ae5a-4b64-b974-e52560612e52 | Apr 28, 2026 |

---

## 🚀 Quick Start Guide

### Open any HTML file instantly
Just double-click any `.html` file — opens in your browser, no server needed.

### Run Math Is Fun (React)
```bash
npx create-react-app mathisfun && cd mathisfun
# Paste MathIsFun.jsx content into src/App.js
npm start
```

### Use Worksheet Generator
1. Open `worksheet-generator.html` in browser
2. Get a free Groq API key at console.groq.com
3. Fill in settings → Generate!

### Deploy BrainGym360
See `05_BrainGym360/DEPLOYMENT.md` for full AWS deployment instructions.
