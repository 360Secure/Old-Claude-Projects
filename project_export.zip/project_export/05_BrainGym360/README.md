# BrainGym360 — Gamified Learning Platform

**Chat URL:** https://claude.ai/chat/fb416a01-0390-40ea-b7e0-5aaa247a991b  
**Date:** April 26, 2026  

## Description
A full-stack gamified educational platform (Duolingo-style) for Grades 1–12 and Adults.
"Get 1% Smarter Every Day"

## Architecture
- **Frontend:** Next.js (React) — deployed at braingym360.com
- **Backend:** Node.js/Express REST API
- **Database:** PostgreSQL with seed data
- **Auth:** Google OAuth 2.0
- **AI:** Claude API (claude-sonnet-4-20250514) for adaptive questions
- **Hosting:** AWS EC2 (ubuntu@16.16.175.224) behind Nginx + SSL
- **Process Manager:** PM2

## User Groups
1. Grades 1–3 — Visual, basic thinking
2. Grades 4–6 — Concept building
3. Grades 7–9 — Logic + application
4. Grades 10–12 — Advanced analytical
5. Adults — Real-life decisions, finance, logic

## Daily Challenge Structure
Each day: Warm-up → Core Thinking → HOTS → Real-Life → Expression → Curiosity → Challenge → Reflection

## Files
- `braingym360-homepage.html` — Static preview of the homepage design
- `DEPLOYMENT.md` — Full deployment instructions for the AWS server

## Live Deployment
```bash
# Upload to server
scp -i ~/360secure.pem ~/Downloads/braingym360_v2_final.zip ubuntu@16.16.175.224:/var/www/

# SSH and deploy
ssh -i ~/360secure.pem ubuntu@16.16.175.224
cd /var/www && unzip -o braingym360_v2_final.zip

# Rebuild
cd /var/www/braingym/frontend && npm install && npm run build
pm2 restart braingym-api && pm2 restart braingym-web
```

## Environment Variables
```
CLAUDE_API_KEY=your_claude_api_key
GOOGLE_CLIENT_ID=1024731703039-l9b1qki661nkd42m5lc0f85kfr89s2cp.apps.googleusercontent.com
NEXT_PUBLIC_API_URL=https://braingym360.com/api
```
