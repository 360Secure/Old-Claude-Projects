# BrainGym360 Deployment Guide

## Server Details
- **URL:** https://braingym360.com
- **Server:** AWS EC2 — ubuntu@16.16.175.224
- **Key:** 360secure.pem
- **Web:** Nginx + SSL (Let's Encrypt)
- **Processes:** PM2 (braingym-api + braingym-web)

## Deploy Steps

### From Mac — Upload via SCP
```bash
scp -i ~/360secure.pem \
  ~/Downloads/braingym360_v2_final.zip \
  ubuntu@16.16.175.224:/var/www/
```

### On Server
```bash
ssh -i ~/360secure.pem ubuntu@16.16.175.224

cd /var/www
unzip -o braingym360_v2_final.zip -d /tmp/v2
cp -r /tmp/v2/braingym360/backend/src /var/www/braingym/backend/
cp -r /tmp/v2/braingym360/frontend/app /var/www/braingym/frontend/

# Update env keys
nano /var/www/braingym/backend/.env
# Add: CLAUDE_API_KEY=your_key

# Rebuild frontend
cd /var/www/braingym/frontend
cat > .env.local << 'ENVEOF'
NEXT_PUBLIC_API_URL=https://braingym360.com/api
NEXT_PUBLIC_GOOGLE_CLIENT_ID=1024731703039-l9b1qki661nkd42m5lc0f85kfr89s2cp.apps.googleusercontent.com
ENVEOF
npm install && npm run build

# Restart
pm2 restart braingym-api --update-env
pm2 restart braingym-web
pm2 status
```

## Check Status
```bash
pm2 status
pm2 logs braingym-api --lines 50
curl https://braingym360.com/api/health
```
